<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends MX_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->helper(['front','url','text']);
        $this->load->model('front_model','fm');   // profil situs
        $this->load->model('M_produk','pm');     // model produk publik
        $this->load->model('M_cart_meja','cm');  // cart shared per-meja
        $this->load->library('session');
        $this->output->set_header('X-Module: produk');
    }

    /* ----------------- Helper Meja/Cart ----------------- */
    private function _ensure_active_cart_id(){
        $meja_kode = $this->session->userdata('guest_meja_kode');
        if (!$meja_kode) return null;
        $cart = $this->cm->ensure_open_cart($meja_kode);
        if ($cart) {
            $this->session->set_userdata('cart_meja_id', (int)$cart->id);
            return (int)$cart->id;
        }
        return null;
    }
    private function _get_active_cart_id(){
        $id = (int)$this->session->userdata('cart_meja_id');
        if ($id > 0) return $id;
        return $this->_ensure_active_cart_id();
    }

    /* ----------------- Listing & Detail ------------------ */
    public function index(){
        $rec = $this->fm->web_me();

        $data["rec"]       = $rec;
        $data["title"]     = "Semua Produk";
        $data["deskripsi"] = "Daftar produk di ".$rec->nama_website." ".$rec->kabupaten.".";
        $data["prev"]      = base_url("assets/images/icon_app.png");

        $data["kategoris"] = $this->pm->get_categories();
        $data["q"]         = $this->input->get('q', true) ?: '';
        $data["kategori"]  = $this->input->get('kategori', true) ?: '';
        $data["sort"]      = $this->input->get('sort', true) ?: 'new';

        $meja_kode         = $this->session->userdata('guest_meja_kode');
        $meja_nama         = $this->session->userdata('guest_meja_nama');
        $data['meja_info'] = $meja_kode ? ($meja_nama ?: $meja_kode) : null;

        $this->load->view('produk_view', $data);
    }

    public function list_ajax(){
        $q        = trim($this->input->get('q', true) ?: '');
        $kategori = $this->input->get('kategori', true) ?: '';
        $sort     = $this->input->get('sort', true) ?: 'new';
        $page     = max(1, (int)($this->input->get('page') ?: 1));
        $per_page = max(1, min(60, (int)($this->input->get('per_page') ?: 12)));
        $offset   = ($page - 1) * $per_page;

        $filters = ['q'=>$q, 'kategori'=>$kategori, 'sold_out'=>($sort==='sold_out')?1:0];

        $total        = $this->pm->count_products($filters);
        $total_pages  = max(1, (int)ceil($total / $per_page));
        $page         = min($page, $total_pages);
        $offset       = ($page - 1) * $per_page;
        $products     = $this->pm->get_products($filters, $per_page, $offset, $sort);

        $items_html = $this->load->view('partials/produk_items_partial', ['products'=>$products], true);
        $pagi_html  = $this->load->view('partials/produk_pagination_partial', ['page'=>$page, 'total_pages'=>$total_pages], true);

        $this->output->set_content_type('application/json')->set_output(json_encode([
            'success'=>true, 'items_html'=>$items_html, 'pagination_html'=>$pagi_html,
            'page'=>$page, 'per_page'=>$per_page, 'total'=>$total, 'total_pages'=>$total_pages,
        ]));
    }

    public function detail($slug = null){
        if (!$slug) show_404();
        $rec  = $this->fm->web_me();
        $prod = $this->pm->get_by_slug($slug);
        if (!$prod) show_404();

        $data["rec"]       = $rec;
        $data["title"]     = $prod->nama." | ".$rec->nama_website;
        $data["deskripsi"] = word_limiter(strip_tags($prod->deskripsi ?: $prod->nama), 30);
        $data["prev"]      = base_url($prod->gambar ?: "assets/images/icon_app.png");
        $data["product"]   = $prod;

        $this->load->view('produk_detail_view', $data);
    }

    public function detail_modal(){
        $slug = $this->input->get('slug', true);
        if (!$slug){
            return $this->output->set_content_type('application/json')
                ->set_output(json_encode(['success'=>false,'html'=>'<div class="p-3 text-danger">Slug tidak diberikan</div>']));
        }
        $prod = $this->pm->get_by_slug($slug);
        if (!$prod){
            return $this->output->set_content_type('application/json')
                ->set_output(json_encode(['success'=>false,'html'=>'<div class="p-3 text-danger">Produk tidak ditemukan</div>']));
        }
        $html = $this->load->view('partials/produk_detail_modal_partial', ['product'=>$prod], true);
        return $this->output->set_content_type('application/json')
            ->set_output(json_encode(['success'=>true,'html'=>$html,'title'=>$prod->nama]));
    }

    /* ----------------- Cart Actions ------------------ */

    public function add_to_cart(){
        $id  = (int)$this->input->post('id');
        $qty = max(1, (int)$this->input->post('qty'));

        $row = $this->db->select('id,nama,sku,harga,stok,gambar,link_seo,is_active')
                        ->get_where('produk', ['id'=>$id, 'is_active'=>1])->row();
        if (!$row) {
            return $this->output->set_content_type('application/json')
                ->set_output(json_encode(['success'=>false,'title'=>'Gagal','pesan'=>'Produk tidak ditemukan']));
        }

        $cart_id = $this->_get_active_cart_id();
        if ($cart_id) {
            $ok = $this->cm->add_item($cart_id, (int)$row->id, $qty, (int)$row->harga);
            $count = $this->cm->count_items($cart_id);

            // meta meja
            $meta = $this->session->userdata('cart_meta') ?: [];
            $meta['meja'] = [
                'id'   => (int)$this->session->userdata('guest_meja_id'),
                'kode' => $this->session->userdata('guest_meja_kode'),
                'nama' => $this->session->userdata('guest_meja_nama'),
            ];
            $this->session->set_userdata('cart_meta', $meta);

            return $this->output->set_content_type('application/json')
                ->set_output(json_encode([
                    'success'=>(bool)$ok, 'count'=>(int)$count,
                    'title'=>$ok?'Berhasil':'Gagal', 'pesan'=>$ok?'Ditambahkan ke keranjang':'Gagal menambahkan'
                ]));
        }

        // Walk-in (tanpa meja)
        $cart = $this->session->userdata('cart__walkin') ?: [];
        if (isset($cart[$id])) $cart[$id]['qty'] += $qty;
        else $cart[$id] = [
            'id'=>(int)$row->id,'nama'=>$row->nama,'harga'=>(int)$row->harga,
            'qty'=>$qty,'slug'=>$row->link_seo,'gambar'=>$row->gambar
        ];
        $this->session->set_userdata('cart__walkin', $cart);

        $count=0; foreach($cart as $c){ $count += (int)$c['qty']; }
        return $this->output->set_content_type('application/json')
            ->set_output(json_encode(['success'=>true,'count'=>(int)$count,'title'=>'Berhasil','pesan'=>'Ditambahkan ke keranjang']));
    }

    public function cart_count(){
        $cart_id = $this->_get_active_cart_id();
        if ($cart_id) {
            $count = $this->cm->count_items($cart_id);
            return $this->output->set_content_type('application/json')
                ->set_output(json_encode(['success'=>true, 'count'=>(int)$count]));
        }
        $cart = $this->session->userdata('cart__walkin') ?: [];
        $cnt=0; foreach($cart as $c){ $cnt+=(int)$c['qty']; }
        return $this->output->set_content_type('application/json')
            ->set_output(json_encode(['success'=>true, 'count'=>(int)$cnt]));
    }

    /** Halaman Cart */
    public function cart(){
        $rec = $this->fm->web_me();

        $cart_id   = $this->_get_active_cart_id(); // null kalau walk-in
        $items     = [];
        $total     = 0;
        $mode      = 'walkin';
        $meja_info = null;

        if ($cart_id) {
            $mode  = 'dinein';
            $items = $this->cm->get_items($cart_id);
            $total = (int)$this->cm->sum_total($cart_id);

            $meja_kode = $this->session->userdata('guest_meja_kode');
            $meja_nama = $this->session->userdata('guest_meja_nama');
            $meja_info = $meja_kode ? ($meja_nama ?: $meja_kode) : null;

        } else {
            // Walk-in (cart di session)
            $sess = $this->session->userdata('cart__walkin') ?: [];
            foreach ($sess as $p) {
                $p = (object)$p;
                $p->produk_id = (int)($p->id ?? 0);
                $p->qty       = (int)($p->qty ?? 0);
                $p->harga     = (int)($p->harga ?? 0);
                $p->subtotal  = $p->qty * $p->harga;
                $items[] = $p;
                $total  += $p->subtotal;
            }
        }

        $data = [
            'rec'        => $rec,
            'title'      => 'Keranjang',
            'deskripsi'  => 'Daftar produk di '.$rec->nama_website.' '.$rec->kabupaten.'.',
            'prev'       => base_url('assets/images/icon_app.png'),
            'mode'       => $mode,
            'items'      => $items,
            'total'      => $total,
            'meja_info'  => $meja_info,
        ];

        $this->load->view('cart_view', $data);
    }

    /** API set qty (plus/minus/input) */
    public function cart_update(){
        $produk_id = (int)$this->input->post('produk_id');
        $qty       = (int)$this->input->post('qty');

        if ($produk_id <= 0) return $this->_json_err('Produk tidak valid');

        $cart_id = $this->_get_active_cart_id();
        if ($cart_id){
            $p = $this->db->select('harga')->get_where('produk',['id'=>$produk_id])->row();
            $harga = $p ? (int)$p->harga : null;
            $ok = $this->cm->set_qty($cart_id, $produk_id, $qty, $harga);
            $count = $this->cm->count_items($cart_id);
            $total = $this->cm->sum_total($cart_id);
            return $this->_json_ok(['count'=>$count, 'total'=>$total, 'ok'=>(bool)$ok]);
        }

        // walkin
        $cart = $this->session->userdata('cart__walkin') ?: [];
        if (!isset($cart[$produk_id])) {
            return $this->_json_err('Item tidak ada di keranjang');
        }
        if ($qty <= 0) unset($cart[$produk_id]);
        else $cart[$produk_id]['qty'] = $qty;
        $this->session->set_userdata('cart__walkin', $cart);

        $count=0; $total=0;
        foreach($cart as $c){ $count += (int)$c['qty']; $total += (int)$c['qty'] * (int)$c['harga']; }
        return $this->_json_ok(['count'=>$count,'total'=>$total]);
    }

    /** API remove baris */
    public function cart_remove(){
        $produk_id = (int)$this->input->post('produk_id');
        if ($produk_id <= 0) return $this->_json_err('Produk tidak valid');

        $cart_id = $this->_get_active_cart_id();
        if ($cart_id){
            $ok = $this->cm->remove_item($cart_id, $produk_id);
            $count = $this->cm->count_items($cart_id);
            $total = $this->cm->sum_total($cart_id);
            return $this->_json_ok(['count'=>$count,'total'=>$total,'ok'=>(bool)$ok]);
        }

        $cart = $this->session->userdata('cart__walkin') ?: [];
        if (isset($cart[$produk_id])) unset($cart[$produk_id]);
        $this->session->set_userdata('cart__walkin', $cart);

        $count=0; $total=0;
        foreach($cart as $c){ $count += (int)$c['qty']; $total += (int)$c['qty'] * (int)$c['harga']; }
        return $this->_json_ok(['count'=>$count,'total'=>$total]);
    }

    /* ----------------- Order Pages ------------------ */

    /** Halaman Order (konfirmasi) */
    public function order(){
        $rec = $this->fm->web_me();

        $cart_id = $this->_get_active_cart_id();
        $items   = [];
        $total   = 0;
        $mode    = 'walkin';
        $meja_info = null;

        if ($cart_id){
            $mode  = 'dinein';
            $items = $this->cm->get_items($cart_id);
            $total = $this->cm->sum_total($cart_id);
            $meja_kode = $this->session->userdata('guest_meja_kode');
            $meja_nama = $this->session->userdata('guest_meja_nama');
            $meja_info = $meja_kode ? ($meja_nama ?: $meja_kode) : null;
        } else {
            $sess = $this->session->userdata('cart__walkin') ?: [];
            foreach($sess as $p){
                $p = (object)$p;
                $p->produk_id = $p->id;
                $p->qty = (int)$p->qty;
                $p->harga = (int)$p->harga;
                $items[] = $p;
                $total += $p->qty * $p->harga;
            }
        }

        $data = [
            'rec'        => $rec,
            'title'      => 'Konfirmasi Pesanan',
            'deskripsi'  => 'Konfirmasi produk di '.$rec->nama_website.' '.$rec->kabupaten.'.',
            'prev'       => base_url('assets/images/icon_app.png'),
            'mode'       => $mode,
            'items'      => $items,
            'total'      => $total,
            'meja_info'  => $meja_info,
        ];

        $this->load->view('order_view', $data);
    }

    /** Submit order → buat pesanan & item dari cart */
    public function submit_order(){
        $nama    = trim($this->input->post('nama', true) ?: '');
        $catatan = trim($this->input->post('catatan', true) ?: '');

        $cart_id = $this->_get_active_cart_id(); // null kalau walk-in
        $mode    = $cart_id ? 'dinein' : 'walkin';

        // === Kumpulkan item dari sumber
        $items = []; $add_total = 0;

        if ($cart_id){
            $items = $this->cm->get_items($cart_id); // asumsikan berisi produk_id, qty, harga, (mungkin nama)
            foreach($items as $it){ $add_total += ((int)$it->qty * (int)$it->harga); }
            if (!$items){ return $this->_json_err('Keranjang kosong'); }
        } else {
            $sess = $this->session->userdata('cart__walkin') ?: [];
            if (!$sess){ return $this->_json_err('Keranjang kosong'); }
            foreach($sess as $it){
                $it = (object)$it;
                $items[] = (object)[
                    'produk_id'=>(int)$it->id,
                    'qty'      =>(int)$it->qty,
                    'harga'    =>(int)$it->harga,
                    'nama'     =>$it->nama ?? null,
                    'slug'     =>$it->slug ?? null,
                    'gambar'   =>$it->gambar ?? null,
                ];
                $add_total += (int)$it->qty * (int)$it->harga;
            }
        }

        $meja_kode = $this->session->userdata('guest_meja_kode');
        $meja_nama = $this->session->userdata('guest_meja_nama');

        $this->db->trans_begin();

        $order_id = null; $nomor = null; $is_append = false; $order_lama = null;

        if ($mode === 'dinein' && $meja_kode){
            // Cek order pending aktif di meja ini
            $order_lama = $this->db->select('id, nomor, total, nama')
                ->from('pesanan')
                ->where(['mode'=>'dinein','meja_kode'=>$meja_kode,'status'=>'pending'])
                ->order_by('id','DESC')->limit(1)->get()->row();

            if ($order_lama){
                $order_id  = (int)$order_lama->id;
                $nomor     = $order_lama->nomor ?: $order_id;
                $is_append = true;

                // Update nama/catatan bila ada input baru
                $upd = [];
                if ($nama !== '')    $upd['nama']    = $nama;
                if ($catatan !== '') {
                    $old_note = $this->db->select('catatan')->get_where('pesanan',['id'=>$order_id])->row();
                    $upd['catatan'] = trim(($old_note->catatan ?? '') !== '' ? (($old_note->catatan)."\n".$catatan) : $catatan);
                }
                if ($upd) $this->db->where('id',$order_id)->update('pesanan', $upd);
            }
        }

        if (!$order_id){
            // Buat order baru
            $nomor = date('YmdHis').'-'.mt_rand(100,999);
            $order_data = [
                'nomor'      => $nomor,
                'mode'       => $mode,
                'meja_kode'  => $meja_kode ?: null,
                'meja_nama'  => $meja_nama ?: null,
                'cart_id'    => $cart_id ?: null,
                'nama'       => $nama ?: null,          // simpan nama customer kalau diisi
                'catatan'    => $catatan ?: null,
                'total'      => (int)$add_total,
                'status'     => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ];
            $this->db->insert('pesanan', $order_data);
            $order_id = (int)$this->db->insert_id();
        }

        // === Siapkan peta nama produk (agar pi.nama terisi)
        $id_set = [];
        foreach($items as $it){ $id_set[(int)$it->produk_id] = true; }
        $map_nama = [];
        if ($id_set){
            $ids = array_keys($id_set);
            $prods = $this->db->select('id, nama')->from('produk')->where_in('id', $ids)->get()->result();
            foreach($prods as $p){ $map_nama[(int)$p->id] = $p->nama; }
        }

        // === Tentukan actor (added_by) & sumber (added_src)
        $actor = 'walkin';
        if ($mode === 'dinein'){
            $actor = $nama ?: ($order_lama->nama ?? '') ?: ($meja_nama ?: ($meja_kode ?: 'customer'));
        }
        $added_src = ($mode === 'dinein') ? 'customer' : 'walkin';

        // === Flag tambahan: 1 jika append ke order pending yang sama, 0 jika buat order baru
        $tambahan_flag = $is_append ? 1 : 0;

        // === INSERT detail ke pesanan_item (isi nama + added_by + added_src + tambahan)
        foreach($items as $it){
            $pid   = (int)$it->produk_id;
            $qty   = (int)$it->qty;
            $harga = (int)$it->harga;
            $nm    = $it->nama ?? ($map_nama[$pid] ?? null);

            $this->db->insert('pesanan_item', [
                'pesanan_id' => $order_id,
                'produk_id'  => $pid,
                'nama'       => $nm,
                'qty'        => $qty,
                'harga'      => $harga,
                'subtotal'   => $qty * $harga,
                'added_src'  => $added_src,       // NEW
                'added_by'   => $actor,           // actor (nama/meja)
                'tambahan'   => $tambahan_flag,   // NEW (0 baru, 1 tambahan)
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        // === Update total header
        $this->db->set('total', 'COALESCE(total,0) + '.(int)$add_total, false)
                 ->where('id', $order_id)->update('pesanan');

        // === Tutup cart
        if ($cart_id){
            $this->db->where('id', $cart_id)->update('cart_meja', [
                'status'     => 'submitted',
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            $this->session->unset_userdata('cart_meja_id');
        } else {
            $this->session->unset_userdata('cart__walkin');
        }

        if ($this->db->trans_status() === FALSE){
            $this->db->trans_rollback();
            return $this->_json_err('Gagal membuat pesanan');
        }
        $this->db->trans_commit();

        return $this->_json_ok([
            'order_id' => (int)$order_id,
            'nomor'    => $nomor ?: $order_id,
            'appended' => (bool)$is_append,
            'message'  => $is_append ? 'Tambahan pesanan ditambahkan ke order aktif' : 'Pesanan baru dibuat',
            'redirect' => site_url('produk/order_success/'.$order_id)
        ]);
    }

    /** Ambil order + items + total dari ID/KODE/nomor. */
    private function _order_bundle($ref){
        $order = null; $items = []; $total = 0; $meja_info = null;

        // --- Ambil header (id | nomor)
        if (ctype_digit((string)$ref)) {
            $order = $this->db->get_where('pesanan', ['id' => (int)$ref])->row();
        } else {
            $order = $this->db->get_where('pesanan', ['nomor' => $ref])->row();
            if (!$order && $this->db->field_exists('kode','pesanan')) {
                $order = $this->db->get_where('pesanan', ['kode' => $ref])->row();
            }
        }
        if (!$order) return [null, [], 0, null];

        // --- Ambil items (pakai nama dari pesanan_item kalau ada) + tambahan
        $q = $this->db->select('
                pi.produk_id,
                COALESCE(pi.nama, p.nama) AS nama,
                pi.harga, pi.qty,
                (pi.harga * pi.qty) AS subtotal,
                pi.tambahan,
                p.gambar, p.link_seo AS slug, p.stok
            ')
            ->from('pesanan_item pi')
            ->join('produk p', 'p.id = pi.produk_id', 'left')
            ->where('pi.pesanan_id', (int)$order->id)
            ->order_by('pi.id','ASC');
        $items = $q->get()->result();

        // normalisasi angka & hitung total
        $total = 0;
        foreach ($items as $it){
            $it->harga    = (int)round((float)$it->harga);
            $it->qty      = (int)$it->qty;
            if (!isset($it->subtotal)) {
                $it->subtotal = $it->harga * $it->qty;
            } else {
                $it->subtotal = (int)round((float)$it->subtotal);
            }
            $it->tambahan = isset($it->tambahan) ? (int)$it->tambahan : 0;
            $total += $it->subtotal;
        }

        // --- Info meja
        if (!empty($order->meja_nama))      $meja_info = $order->meja_nama;
        elseif (!empty($order->meja_kode))  $meja_info = $order->meja_kode;

        return [$order, $items, $total, $meja_info];
    }

    public function order_success($id = null){
        if (!$id) show_404();
        $rec = $this->fm->web_me();

        [$order, $items, $total, $meja_info] = $this->_order_bundle($id);
        if (!$order) show_404();

        $paid_method = isset($order->paid_method) ? $order->paid_method : null;
		$method = $this->input->get('method', true) ?: $paid_method;

		$data = [
		    'rec'       => $rec,
		    'title'     => 'Pesanan Diterima',
		    'deskripsi' => 'Konfirmasi produk di '.$rec->nama_website.' '.$rec->kabupaten.'.',
		    'prev'      => base_url('assets/images/icon_app.png'),
		    'order'     => $order,
		    'items'     => $items,
		    'total'     => $total,
		    'meja_info' => $meja_info,
		    'method'    => $method,           // ✅ tambahkan ini
		];
        $this->load->view('order_success_view', $data);
    }

    /** Cetak struk thermal (58mm/80mm). URL: produk/order_print/{ID atau KODE} */
    public function order_print($id = null){
        if (!$id) show_404();
        [$order, $items, $total, $meja_info] = $this->_order_bundle($id);
        if (!$order) show_404();
        $data = compact('order','items','total','meja_info');
        $this->load->view('order_receipt_view', $data);
    }

    /* ----------------- Tag Meja (QR) ------------------ */
    public function tag($kode = null){
        $kode = trim((string)$kode);
        if ($kode === '') return redirect('produk');

        // Penting: buat sesi baru setiap scan barcode meja
        $this->session->sess_regenerate(TRUE);

        $row = $this->db->get_where('meja', ['kode'=>$kode, 'status'=>'aktif'])->row();

        if ($row) {
            $this->session->set_userdata([
                'guest_meja_id'   => (int)$row->id,
                'guest_meja_kode' => $row->kode,
                'guest_meja_nama' => $row->nama,
            ]);
            $cart = $this->cm->ensure_open_cart($row->kode);
            if ($cart) $this->session->set_userdata('cart_meja_id', (int)$cart->id);

            // legacy cleanup (jika ada)
            if ($this->session->userdata('cart')) $this->session->unset_userdata('cart');

            $this->session->set_flashdata('cart_reset_msg','Anda memesan dari '.$row->nama.' ('.$row->kode.').');
        } else {
            $this->session->unset_userdata(['guest_meja_id','guest_meja_kode','guest_meja_nama','cart_meja_id']);
        }
        return redirect('produk');
    }

    /* ----------------- Pembayaran (tanpa API) ------------------ */
    private function _mark_paid($id, $method){
        $id = (int)$id;
        $row = $this->db->get_where('pesanan',['id'=>$id])->row();
        if (!$row) show_404();

        // jika sudah paid/canceled, jangan diubah
        if (in_array($row->status, ['paid','canceled'], true)){
            return redirect('produk/order_success/'.$id);
        }

        $data = [
            'status'      => 'paid',
            'paid_method' => $method,      // 'cash' | 'qris' | 'transfer' (pastikan enum DB sudah ada jika pakai transfer)
            'paid_at'     => date('Y-m-d H:i:s'),
        ];
        $this->db->where('id',$id)->update('pesanan', $data);
        redirect('produk/order_success/'.$id);
    }

    public function pay_cash($id){    return $this->_mark_paid($id, 'cash'); }
    public function pay_qris($id){    return $this->_mark_paid($id, 'qris'); }

    // Jika enum DB sudah ditambah 'transfer', aktifkan baris di bawah.
    // public function pay_transfer($id){ return $this->_mark_paid($id, 'transfer'); }

    // Jika belum ingin ubah enum, arahkan ke halaman instruksi transfer (status tetap pending):
    // --- di dalam class Produk ---

/* === Transfer: halaman instruksi + upload bukti === */
public function pay_transfer($id = null){
    $id = (int)$id;
    if (!$id) show_404();

    // ambil order
    $order = $this->db->get_where('pesanan', ['id'=>$id])->row();
    if (!$order) show_404();

    // kalau sudah paid/canceled, balik ke success
    if (in_array($order->status, ['paid','canceled'], true)) {
        return redirect('produk/order_success/'.$id);
    }

    // Set paid_method=transfer (status tetap pending)
    if (($order->paid_method ?? '') !== 'transfer') {
        $this->db->where('id',$id)->update('pesanan', [
            'paid_method' => 'transfer'
        ]);
        // refresh object kalau mau
        $order = $this->db->get_where('pesanan', ['id'=>$id])->row();
    }

    // data profil situs & total, items
    [$order2, $items, $total, $meja_info] = $this->_order_bundle($id);

    $rec = $this->fm->web_me();

    $data = [
    	'title'      => 'Pembayaran via Transfer',
    	'deskripsi'  => 'Konfirmasi produk di '.$rec->nama_website.' '.$rec->kabupaten.'.',
    	'prev'       => base_url('assets/images/icon_app.png'),
        'rec'        => $rec,
        'order'      => $order2 ?: $order,
        'items'      => $items,
        'total'      => $total,
        'meja_info'  => $meja_info,
        'method' => 'transfer',
        // Optional: teks rekening (bisa diambil dari pengaturan DB Anda)
        'bank_list'  => [
            [
                'bank' => 'BCA',
                'atas_nama' => 'PT Contoh Sukses',
                'no_rek' => '1234567890',
            ],
            [
                'bank' => 'BNI',
                'atas_nama' => 'PT Contoh Sukses',
                'no_rek' => '9876543210',
            ],
        ],
    ];

    $this->load->view('pay_transfer_view', $data);
}

// === Upload bukti bayar (TRANSFER) ===
public function upload_bukti($id = null){
    $id = (int)$id;
    if ($id <= 0) show_404();

    // validasi order
    $order = $this->db->get_where('pesanan', ['id'=>$id])->row();
    if (!$order) show_404();

    // setup upload
    $config = [
        'upload_path'   => FCPATH.'uploads/bukti/',
        'allowed_types' => 'jpg|jpeg|png|webp|pdf',
        'max_size'      => 4096, // 4MB
        'encrypt_name'  => true,
    ];
    if (!is_dir($config['upload_path'])) @mkdir($config['upload_path'], 0775, true);
    $this->load->library('upload', $config);

    if (!$this->upload->do_upload('bukti')){
        $this->session->set_flashdata('upload_err', $this->upload->display_errors('', ''));
        // balik ke order_success dengan mode transfer agar form tetap terlihat
        return redirect('produk/order_success/'.$id.'?method=transfer');
    }

    $up = $this->upload->data();
    $rel = 'uploads/bukti/'.$up['file_name'];

    // simpan ke DB — set paid_method tetap "transfer"; status boleh tetap "pending"
    // atau langsung "paid" kalau kamu memang auto-approve
    $this->db->where('id', $id)->update('pesanan', [
        'bukti_bayar' => $rel,
        'paid_method' => 'transfer',
        // 'status'    => 'paid', // <- aktifkan jika mau auto “paid”
        'updated_at'  => date('Y-m-d H:i:s'),
    ]);

    $this->session->set_flashdata('upload_ok', 'Bukti transfer berhasil diunggah.');

    // >>> ARAHKAN KE HALAMAN CETAK STRUK <<<
    return redirect('produk/receipt/'.$id);
}

/** Halaman struk full page (untuk cetak) */
public function receipt($id = null){
    if (!$id) show_404();
    [$order, $items, $total, $meja_info] = $this->_order_bundle($id);
    if (!$order) show_404();

    $rec = $this->fm->web_me();
    $data = compact('order','items','total','meja_info','rec');

    // halaman full (bukan modal) untuk cetak
    $this->load->view('order_receipt_page', $data);
}

/* === Upload bukti transfer === */
public function pay_transfer_upload($id = null){
    $id = (int)$id;
    if (!$id) show_404();

    $order = $this->db->get_where('pesanan',['id'=>$id])->row();
    if (!$order) show_404();

    // jika sudah paid/canceled, tak perlu upload lagi
    if (in_array($order->status, ['paid','canceled'], true)) {
        $this->session->set_flashdata('msg_info','Pesanan sudah selesai.');
        return redirect('produk/order_success/'.$id);
    }

    // Validasi ada file?
    if (empty($_FILES['bukti']['name'])) {
        $this->session->set_flashdata('msg_err','Pilih file bukti terlebih dahulu.');
        return redirect('produk/pay_transfer/'.$id);
    }

    // Siapkan direktori
    $ym = date('Ym');
    $path = FCPATH.'uploads/transfer/'.$ym.'/';
    if (!is_dir($path)) { @mkdir($path, 0775, true); }

    // Nama file aman
    $ext  = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
    $ext  = strtolower(preg_replace('/[^a-z0-9]/i','',$ext));
    if ($ext === '') $ext = 'jpg';
    $fname = 'bukti_'.$id.'_'.date('YmdHis').'.'.$ext;
    $dest  = $path.$fname;

    // Validasi mime sederhana
    $allowed = [
        'image/jpeg','image/png','image/gif',
        'application/pdf','image/webp','image/heic'
    ];
    $mime = $_FILES['bukti']['type'] ?? '';
    if (!in_array($mime, $allowed, true)) {
        $this->session->set_flashdata('msg_err','Format bukti harus JPG/PNG/GIF/WEBP/HEIC atau PDF.');
        return redirect('produk/pay_transfer/'.$id);
    }

    // Pindahkan file
    if (!@move_uploaded_file($_FILES['bukti']['tmp_name'], $dest)) {
        $this->session->set_flashdata('msg_err','Gagal mengunggah bukti, coba lagi.');
        return redirect('produk/pay_transfer/'.$id);
    }

    // URL publik
    $public_url = base_url('uploads/transfer/'.$ym.'/'.$fname);

    // Catat ke kolom catatan (tanpa ubah struktur), set paid_method=transfer
    $note_append = "Bukti transfer: ".$public_url;
    $new_note = trim(($order->catatan ?? '') !== '' ? (($order->catatan)."\n".$note_append) : $note_append);

    $this->db->where('id',$id)->update('pesanan', [
        'paid_method' => 'transfer',
        'catatan'     => $new_note,
    ]);

    $this->session->set_flashdata('msg_ok','Bukti transfer terkirim. Mohon tunggu verifikasi kasir.');
    return redirect('produk/order_success/'.$id);
}

/* === (Opsional) Admin/Kasir menandai lunas setelah verifikasi ===
   Anda bisa panggil dari halaman admin; di sini disiapkan endpoint sederhana. */
public function mark_transfer_paid($id = null, $secret = null){
    // SIMPLE GUARD: ganti 'YOUR_SECRET_TOKEN' dengan token environment Anda
    if ($secret !== 'YOUR_SECRET_TOKEN') show_404();

    $id = (int)$id;
    if (!$id) show_404();

    $row = $this->db->get_where('pesanan',['id'=>$id])->row();
    if (!$row) show_404();

    if (!in_array($row->status, ['paid'], true)) {
        $this->db->where('id',$id)->update('pesanan', [
            'status'      => 'paid',
            'paid_method' => 'transfer',
            'paid_at'     => date('Y-m-d H:i:s')
        ]);
    }
    $this->session->set_flashdata('msg_ok','Pesanan ditandai lunas (transfer).');
    return redirect('produk/order_success/'.$id);
}


    /* ----------------- JSON helper ------------------ */
    private function _json_ok($extra=[]){
        $extra['success'] = true;
        return $this->output->set_content_type('application/json')->set_output(json_encode($extra));
    }
    private function _json_err($msg='Error', $extra=[]){
        $extra['success'] = false; $extra['title'] = 'Gagal'; $extra['pesan'] = $msg;
        return $this->output->set_content_type('application/json')->set_output(json_encode($extra));
    }

    // Preview struk di modal (AJAX)
    public function order_receipt_modal($id = null){
        if (!$id) show_404();

        [$order, $items, $total, $meja_info] = $this->_order_bundle($id);
        if (!$order) show_404();

        $rec  = $this->fm->web_me();
        $html = $this->load->view(
            'partials/order_receipt_partial',
            compact('order','items','total','meja_info','rec'),
            true
        );

        $title = 'Struk #'.($order->nomor ?? $order->kode ?? $order->id);
        return $this->output->set_content_type('application/json')
            ->set_output(json_encode(['success'=>true,'html'=>$html,'title'=>$title]));
    }


}
