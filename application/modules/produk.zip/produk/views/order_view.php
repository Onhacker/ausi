<?php $this->load->view("front_end/head.php"); ?>
<style>
  /* Tumpuk tombol aksi di mobile */
  @media (max-width: 767.98px){
    .actions-wrap{ flex-direction: column !important; align-items: stretch !important; gap:.5rem; }
    .actions-wrap .btn{ width: 100%; }
  }
  /* Kartu item di mobile */
  .item-card{ border:1px solid #eef2f7; border-radius:12px; padding:.75rem; margin-bottom:.5rem; }
  .item-card .row{ align-items:center; }
  .price, .subtotal{ font-weight:600; }
  .muted{ color:#6c757d; font-size:.9rem; }
</style>

<div class="container-fluid">
  <div class="hero-title" role="banner" aria-label="Judul halaman">
    <h1 class="text">Konfirmasi Pesanan</h1>
    
    <span class="accent" aria-hidden="true"></span>
  </div>
   <div class="col-12">
  <div class="text-center">
    <i class="h1 mdi mdi-chair-school text-muted" aria-hidden="true"></i>
    <h3 class="mb-3">
      <?php if (!empty($meja_info)): ?>
        <span class="badge badge-success">Table: <?= html_escape($meja_info) ?></span>
      <?php else: ?>
        <span class="badge badge-secondary">Mode: Takeaway / Walk-in</span>
      <?php endif; ?>
    </h3>
  </div>
</div>

  <div class="card card-body">
    <?php if (empty($items)): ?>
  <div class="text-center py-5">
    <h5>Keranjang kosong</h5>
    <a href="<?= site_url('produk') ?>" class="btn btn-primary mt-3">
      <i class="mdi mdi-arrow-left"></i> Kembali ke Menu
    </a>
  </div>
<?php else: ?>

  <!-- Tabel (desktop & tablet) -->
  <div class="table-responsive d-none d-md-block">
    <table class="table table-centered table-striped mb-0">
      <thead class="thead-light">
        <tr>
          <th>Produk</th>
          <th class="text-center" style="width:120px">Qty</th>
          <th class="text-right" style="width:140px">Harga</th>
          <th class="text-right" style="width:160px">Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($items as $it): $harga=(int)$it->harga; $qty=(int)$it->qty; ?>
          <tr>
            <td><?= html_escape($it->nama ?? '') ?></td>
            <td class="text-center"><?= $qty ?></td>
            <td class="text-right">Rp <?= number_format($harga,0,',','.') ?></td>
            <td class="text-right">Rp <?= number_format($harga*$qty,0,',','.') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <th colspan="3" class="text-right">Total</th>
          <th class="text-right">Rp <?= number_format((int)$total,0,',','.') ?></th>
        </tr>
      </tfoot>
    </table>
  </div>

  <!-- Kartu (mobile) -->
  <div class="d-md-none">
    <?php foreach($items as $it):
      $nama  = $it->nama ?? '';
      $harga = (int)$it->harga; $qty = (int)$it->qty; $sub = $harga*$qty;
    ?>
      <div class="item-card">
        <div class="row">
          <div class="col-8">
            <div class="font-weight-600"><?= html_escape($nama) ?></div>
            <div class="muted">Harga: Rp <?= number_format($harga,0,',','.') ?></div>
            <div class="muted">Qty: <strong><?= $qty ?></strong></div>
          </div>
          <div class="col-4 text-right">
            <div class="subtotal">Rp <?= number_format($sub,0,',','.') ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>

    <div class="d-flex justify-content-between border-top pt-2 mt-2">
      <div class="font-weight-600">Total</div>
      <div class="font-weight-700">Rp <?= number_format((int)$total,0,',','.') ?></div>
    </div>
  </div>

  <hr>

  <!-- Form tetap otomatis stack di mobile karena pakai col-md-6 -->
  <form id="form-order" onsubmit="return false;">
    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Nama (opsional)</label>
        <input type="text" class="form-control" name="nama" placeholder="Nama pelanggan">
      </div>
      <div class="form-group col-md-6">
        <label>Catatan</label>
        <input type="text" class="form-control" name="catatan" placeholder="Tanpa gula / pedas / dll">
      </div>
    </div>
  </form>

  <!-- Aksi -->
  <div class="d-flex justify-content-between align-items-center actions-wrap">
    <a href="<?= site_url('produk/cart') ?>" class="btn btn-outline-secondary">
      <i class="mdi mdi-arrow-left"></i> Kembali
    </a>
    <button id="btn-order" class="btn btn-success">
      Buat Pesanan <i class="mdi mdi-check-bold ml-1"></i>
    </button>
  </div>

<?php endif; ?>

  </div>
</div>

<script src="<?php echo base_url('assets/admin') ?>/js/vendor.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/app.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/sw.min.js"></script>
<script>
(function(){
  $('#btn-order').on('click', function(){
    const fd = new FormData(document.getElementById('form-order'));
    Swal.fire({title:'Memproses...', allowOutsideClick:false, didOpen:()=>Swal.showLoading()});
    $.ajax({
      url: "<?= site_url('produk/submit_order'); ?>",
      type: "POST",
      data: fd, processData:false, contentType:false, dataType:'json'
    }).done(function(r){
      Swal.close();
      if (!r || !r.success) {
        Swal.fire('Gagal', r?.pesan||'Tidak bisa membuat pesanan', 'error');
        return;
      }
      Swal.fire({title:'Pesanan diterima', icon:'success', timer:1200, showConfirmButton:false});
      setTimeout(()=> { window.location.href = r.redirect; }, 900);
    }).fail(function(){
      Swal.close();
      Swal.fire('Error','Koneksi bermasalah','error');
    });
  });
})();
</script>
<?php $this->load->view("front_end/footer.php"); ?>
