<?php $this->load->view("front_end/head.php"); ?>
<div class="container my-3">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Struk Pesanan</h4>
    <div>
      <a href="<?= site_url('produk/order_success/'.(int)$order->id) ?>" class="btn btn-light">
        <i class="mdi mdi-arrow-left"></i> Kembali
      </a>
      <button id="btnPrintNow" class="btn btn-primary">
        <i class="mdi mdi-printer"></i> Cetak
      </button>
    </div>
  </div>

  <!-- Pakai partial struk yang sudah ada supaya konsisten dengan modal -->
  <div class="card">
    <div class="card-body">
      <?php
      // partial ini sudah kamu gunakan di modal: 'partials/order_receipt_partial'
      // pastikan partial tersebut menghasilkan <div class="printable-receipt">...</div>
      $this->load->view(
        'partials/order_receipt_partial',
        compact('order','items','total','meja_info','rec')
      );
      ?>
    </div>
  </div>

  <div class="alert alert-info mt-3">
    Bukti bayar:
    <?php if (!empty($order->bukti_bayar)): ?>
      <?php if (preg_match('~\.(png|jpe?g|webp)$~i', $order->bukti_bayar)): ?>
        <a href="<?= base_url($order->bukti_bayar) ?>" target="_blank" rel="noopener">Lihat gambar</a>
      <?php else: ?>
        <a href="<?= base_url($order->bukti_bayar) ?>" target="_blank" rel="noopener">Lihat file</a>
      <?php endif; ?>
    <?php else: ?>
      <em>Belum diunggah.</em>
    <?php endif; ?>
  </div>

  <div class="text-muted small mt-2">
    Tips: Jika dialog print tidak muncul otomatis, klik tombol <strong>Cetak</strong>.
  </div>
</div>

<script>
// auto pop up print begitu halaman siap
window.addEventListener('load', function(){
  setTimeout(function(){ window.print(); }, 300);
});

document.getElementById('btnPrintNow')?.addEventListener('click', function(){
  window.print();
});
</script>

<?php $this->load->view("front_end/footer.php"); ?>
