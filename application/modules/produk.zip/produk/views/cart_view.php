<?php $this->load->view("front_end/head.php"); ?>
<div class="container-fluid">
  <div class="hero-title" role="banner" aria-label="Judul halaman">
    <h1 class="text">Keranjang</h1>
   
    <span class="accent" aria-hidden="true"></span>
  </div>
  <div class="col-12">
  <div class="text-center">
    <i class="h1 mdi mdi-chair-school text-muted" aria-hidden="true"></i>
    <h3 class="mb-3">
      <?php if (!empty($meja_info)): ?>
        <span class="badge badge-success">Table: <?= html_escape($meja_info) ?></span>
      <?php else: ?>
        <span class="badge badge-secondary">Mode: Takeaway / Walk-in</span>
      <?php endif; ?>
    </h3>
  </div>
</div>

  <div class="card card-body">
    <?php if (empty($items)): ?>
      <div class="text-center py-5">
        <h5>Keranjang masih kosong</h5>
        <a href="<?= site_url('produk') ?>" class="btn btn-primary mt-3">
          <i class="mdi mdi-arrow-left"></i> Kembali ke Menu
        </a>
      </div>
    <?php else: ?>
      <div class="table-responsive">
  <table class="table table-centered table-striped mb-0 cart-table">
    <thead class="thead-light">
      <tr>
        <th style="width:64px">Gambar</th>
        <th>Produk</th>
        <th class="text-right" style="width:140px">Harga</th>
        <th class="text-center" style="width:200px">Qty</th>
        <th class="text-right" style="width:140px">Subtotal</th>
        <th class="text-center" style="width:80px">Hapus</th>
      </tr>
    </thead>
    <tbody id="cart-tbody">
      <?php foreach($items as $it):
        $img   = $it->gambar ? base_url($it->gambar) : base_url('assets/images/icon_app.png');
        $harga = (int)$it->harga;
        $qty   = (int)$it->qty;
        $sub   = $harga * $qty;
      ?>
      <tr data-id="<?= (int)$it->produk_id ?>">
        <td class="no-label" data-label="Gambar">
          <img src="<?= $img ?>" class="img-fluid rounded" alt="">
        </td>

        <td data-label="Produk">
          <div class="font-weight-600 mb-1"><?= html_escape($it->nama ?? '') ?></div>
          <?php if (!empty($it->slug)): ?>
            <small><a href="javascript:void(0)" class="link-detail" data-slug="<?= html_escape($it->slug) ?>">Lihat detail</a></small>
          <?php endif; ?>
        </td>

        <td class="text-right" data-label="Harga">
          <span class="harga" data-harga="<?= $harga ?>">Rp <?= number_format($harga,0,',','.') ?></span>
        </td>

        <td class="text-center" data-label="Qty">
          <div class="input-group input-group-sm justify-content-center" style="max-width:200px">
            <div class="input-group-prepend">
              <button class="btn btn-light btn-dec" type="button"><i class="mdi mdi-minus"></i></button>
            </div>
            <input type="number" min="0" step="1" class="form-control text-center qty-input" value="<?= $qty ?>" style="max-width:90px">
            <div class="input-group-append">
              <button class="btn btn-light btn-inc" type="button"><i class="mdi mdi-plus"></i></button>
            </div>
          </div>
          <!-- <?php if (isset($it->stok)): ?>
            <small class="text-muted d-block">Stok: <?= (int)$it->stok ?></small>
          <?php endif; ?> -->
        </td>

        <td class="text-right subtotal" data-label="Subtotal">
          Rp <?= number_format($sub,0,',','.') ?>
        </td>

        <td class="text-center no-label" data-label="Hapus">
          <button class="btn btn-sm btn-outline-danger btn-remove" type="button">
            <i class="mdi mdi-trash-can-outline"></i>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>

    <tfoot>
      <tr>
        <th colspan="4" class="text-right">Total</th>
        <th class="text-right" id="cart-total">Rp <?= number_format((int)$total,0,',','.') ?></th>
        <th></th>
      </tr>
    </tfoot>
  </table>
</div>


      <div class="d-flex flex-wrap justify-content-between align-items-center mt-3">
        <a href="<?= site_url('produk') ?>" class="btn btn-outline-secondary">
          <i class="mdi mdi-arrow-left"></i> Kembali
        </a>
        <a href="<?= site_url('produk/order') ?>" class="btn btn-success">
          Lanjutkan Pesan <i class="mdi mdi-arrow-right ml-1"></i>
        </a>
      </div>
    <?php endif; ?>
  </div>
</div>

<script src="<?php echo base_url('assets/admin') ?>/js/vendor.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/app.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/sw.min.js"></script>
<style>
/* ===== Cart table: desktop normal, mobile jadi stacked ===== */
.cart-table thead th { white-space: nowrap; }

/* Mobile */
@media (max-width: 767.98px){
  .cart-table { border-collapse: separate; border-spacing: 0 12px; }
  .cart-table thead { display: none; }                /* sembunyikan header */

  .cart-table tbody tr {
    display: block;
    background: #fff;
    border: 1px solid #eef2f7;
    border-radius: 12px;
    padding: .75rem .75rem .5rem;
    box-shadow: 0 8px 20px rgba(16,24,40,.04);
  }

  .cart-table tbody td {
    display: flex;                                     /* label kiri, nilai kanan */
    align-items: center;
    justify-content: space-between;
    width: 100%;
    border: 0 !important;
    padding: .375rem 0;
    text-align: right;                                 /* nilai rata kanan */
  }
  .cart-table tbody td::before {
    content: attr(data-label);
    font-weight: 600;
    color: #6b7280;
    margin-right: .75rem;
    text-align: left;                                  /* label rata kiri */
  }
  /* Kolom gambar & aksi: label tidak perlu */
  .cart-table td.no-label::before { content: none; }

  /* Gambar lebih besar sedikit biar enak dilihat */
  .cart-table .img-fluid { width: 64px; height: 64px; object-fit: cover; }

  /* Grup qty full width */
  .cart-table .input-group { width: 100%; max-width: none !important; }

  /* Footer total juga stacked */
  .cart-table tfoot, .cart-table tfoot tr, .cart-table tfoot th {
    display: block; width: 100%; border: 0 !important; padding: 0;
  }
  .cart-table tfoot tr {
    margin-top: .25rem;
    background: #f9fafb;
    border-radius: 12px;
    padding: .5rem .75rem;
  }
  #cart-total { display: inline-block; }
}
</style>

<script>
(function(){
  const fmt = n => 'Rp ' + (n||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.');

  function updateRowTotal($tr){
    const harga = parseInt($tr.find('.harga').data('harga')||0);
    const qty   = Math.max(0, parseInt($tr.find('.qty-input').val()||0));
    $tr.find('.subtotal').text(fmt(harga*qty));
  }
  function postUpdate(produk_id, qty){
    return $.post("<?= site_url('produk/cart_update'); ?>", {produk_id, qty}, null, 'json');
  }
  function postRemove(produk_id){
    return $.post("<?= site_url('produk/cart_remove'); ?>", {produk_id}, null, 'json');
  }

  // plus/minus
  $('#cart-tbody').on('click','.btn-inc', function(){
    const $tr = $(this).closest('tr'); const id = parseInt($tr.data('id')); if (!id) return;
    let q = parseInt($tr.find('.qty-input').val()||0) + 1;
    $tr.find('.qty-input').val(q); updateRowTotal($tr);
    postUpdate(id, q).done(r=>{
      if (r && r.success){
        $('#cart-total').text(fmt(r.total||0));
        $('#cart-count').text(r.count||0);
      } else { Swal.fire('Gagal', r?.pesan||'Tidak bisa update', 'error'); }
    }).fail(()=> Swal.fire('Error','Koneksi bermasalah','error'));
  });

  $('#cart-tbody').on('click','.btn-dec', function(){
    const $tr = $(this).closest('tr'); const id = parseInt($tr.data('id')); if (!id) return;
    let q = Math.max(0, parseInt($tr.find('.qty-input').val()||0) - 1);
    $tr.find('.qty-input').val(q); updateRowTotal($tr);
    postUpdate(id, q).done(r=>{
      if (r && r.success){
        if (q <= 0) { $tr.remove(); }
        $('#cart-total').text(fmt(r.total||0));
        $('#cart-count').text(r.count||0);
        if ((r.count||0) === 0) { window.location.reload(); }
      } else { Swal.fire('Gagal', r?.pesan||'Tidak bisa update', 'error'); }
    }).fail(()=> Swal.fire('Error','Koneksi bermasalah','error'));
  });

  // manual input
  $('#cart-tbody').on('change','.qty-input', function(){
    const $tr = $(this).closest('tr'); const id = parseInt($tr.data('id')); if (!id) return;
    let q = Math.max(0, parseInt($(this).val()||0));
    $(this).val(q); updateRowTotal($tr);
    postUpdate(id, q).done(r=>{
      if (r && r.success){
        if (q <= 0) { $tr.remove(); }
        $('#cart-total').text(fmt(r.total||0));
        $('#cart-count').text(r.count||0);
        if ((r.count||0) === 0) { window.location.reload(); }
      } else { Swal.fire('Gagal', r?.pesan||'Tidak bisa update', 'error'); }
    }).fail(()=> Swal.fire('Error','Koneksi bermasalah','error'));
  });

  // remove
  $('#cart-tbody').on('click','.btn-remove', function(){
    const $tr = $(this).closest('tr'); const id = parseInt($tr.data('id')); if (!id) return;
    Swal.fire({title:'Hapus item?', icon:'warning', showCancelButton:true, confirmButtonText:'Ya, hapus', cancelButtonText:'Batal'})
      .then(res=>{
        if (!res.isConfirmed) return;
        postRemove(id).done(r=>{
          if (r && r.success){
            $tr.remove();
            $('#cart-total').text(fmt(r.total||0));
            $('#cart-count').text(r.count||0);
            if ((r.count||0) === 0) { window.location.reload(); }
          } else { Swal.fire('Gagal', r?.pesan||'Tidak bisa menghapus', 'error'); }
        }).fail(()=> Swal.fire('Error','Koneksi bermasalah','error'));
      });
  });
})();
</script>
<script>
  // Pakai modal yang sama (#modalProduk) untuk detail dari halaman cart
  (function(){
    // pastikan modal ada di <body>
    var $m = $('#modalProduk'); if ($m.length) $m.appendTo('body');

    $('#cart-tbody').on('click', '.link-detail', function(e){
      e.preventDefault();
      var slug = $(this).data('slug');
      $('#modalProdukTitle').text('Detail Produk');
      $('#modalProdukBody').html('<div class="text-center py-5 text-muted">Memuat…</div>');
      $('#modalProduk').modal('show');

      $.getJSON("<?= site_url('produk/detail_modal'); ?>", { slug: slug })
        .done(function(r){
          if (!r || !r.success){ $('#modalProdukBody').html('<div class="text-danger p-3">Gagal memuat detail.</div>'); return; }
          if (r.title) $('#modalProdukTitle').text(r.title);
          $('#modalProdukBody').html(r.html);
        })
        .fail(function(){
          $('#modalProdukBody').html('<div class="text-danger p-3">Koneksi bermasalah.</div>');
        });
    });
  })();
</script>

<!-- ================= MODAL PRODUK (Wajib ada di cart) ================ -->
<style>
  /* Pastikan modal nongol di atas komponen lain & body tidak blur */
  #modalProduk.modal            { z-index: 200001 !important; pointer-events: auto !important; }
  .modal-backdrop               { z-index: 199991 !important; pointer-events: none !important; }
  #modalProduk .modal-content   { border:0; border-radius:16px; box-shadow:0 20px 40px rgba(0,0,0,.18); }
  #modalProduk .modal-header,
  #modalProduk .modal-footer    { border:0; }

  /* Scroll enak: tinggi dialog menyesuaikan viewport */
  #modalProduk .modal-dialog{ margin: 1.25rem auto; }
  #modalProduk .modal-content{
    display:flex; flex-direction:column;
    max-height:calc(100vh - 2.5rem);
  }
  #modalProduk .modal-body{
    flex:1 1 auto; overflow:auto !important; -webkit-overflow-scrolling:touch;
  }
  @media (max-width: 767.98px){
    #modalProduk .modal-dialog{ margin:.75rem auto; }
    #modalProduk .modal-content{ max-height:calc(100vh - 1.5rem); }
  }
  #modalProduk .modal-dialog{
  margin: 1.25rem auto;                 /* ruang atas-bawah */
  height: auto !important;              /* cegah tinggi 100% dari tema */
  max-height: none !important;
}
</style>

<div class="modal fade" id="modalProduk" tabindex="-1" aria-hidden="true" aria-labelledby="modalProdukTitle">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="modalProdukTitle" class="modal-title">Detail Produk</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modalProdukBody">
        <div class="text-center py-5 text-muted">Memuat…</div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Pastikan modal berada langsung di body (hindari parent yg ter-transform/blur)
  var $m = $('#modalProduk'); if ($m.length) $m.appendTo('body');

  // Bersihkan masker aneh (jika ada lib lain)
  window.killMasks = function () {
    $('.window-mask, .messager-mask, .datagrid-mask, .easyui-mask, .mm-wrapper__blocker')
      .css('pointer-events','none').hide();
  };

  $('#modalProduk')
    .on('show.bs.modal', function(){ window.killMasks && window.killMasks(); })
    .on('shown.bs.modal', function(){
      window.killMasks && window.killMasks();
      // beberapa lib suka munculkan masker lagi → bersihkan sebentar
      var tries = 0, iv = setInterval(function(){
        window.killMasks && window.killMasks();
        if (++tries > 15) clearInterval(iv);
      }, 120);
      $(this).data('maskIv', iv);
    })
    .on('hide.bs.modal', function(){
      var iv = $(this).data('maskIv'); if (iv) clearInterval(iv);
    });

  // Handler “Lihat detail” (link di tabel keranjang)
  $('#cart-tbody').off('click', '.link-detail').on('click', '.link-detail', function(e){
    e.preventDefault();
    var slug = $(this).data('slug');
    $('#modalProdukTitle').text('Detail Produk');
    $('#modalProdukBody').html('<div class="text-center py-5 text-muted">Memuat…</div>');
    $('#modalProduk').modal('show');

    $.getJSON("<?= site_url('produk/detail_modal'); ?>", { slug: slug })
      .done(function(r){
        if (!r || !r.success){
          $('#modalProdukBody').html('<div class="text-danger p-3">Gagal memuat detail.</div>');
          return;
        }
        if (r.title) $('#modalProdukTitle').text(r.title);
        $('#modalProdukBody').html(r.html);
      })
      .fail(function(){
        $('#modalProdukBody').html('<div class="text-danger p-3">Koneksi bermasalah.</div>');
      });
  });

  // Tambah ke keranjang dari dalam modal (delegation)
  $('#modalProduk').off('click', '#btn-add-cart-modal').on('click', '#btn-add-cart-modal', function(e){
    e.preventDefault();
    var $btn = $(this);
    var id   = $btn.data('id');
    var qty  = parseInt($('#qty-modal').val() || 1);

    $btn.prop('disabled', true);

    $.ajax({
      url: "<?= site_url('produk/add_to_cart'); ?>",
      type: "POST",
      dataType: "json",
      data: { id: id, qty: qty }
    }).done(function(r){
      if (!r || !r.success){
        if (window.Swal) Swal.fire({icon:'error', title:'Gagal', text: (r && r.pesan) || 'Tidak bisa menambahkan'});
        else alert((r && r.pesan) || 'Gagal menambahkan');
        return;
      }
      // Tutup modal dulu, lalu reload halaman agar qty/total di tabel ikut terupdate
      $('#modalProduk').one('hidden.bs.modal', function(){
        if (window.Swal) {
          Swal.fire({ icon:'success', title:'Berhasil', text:'Ditambahkan ke keranjang', timer:900, showConfirmButton:false });
        }
        // reload untuk sync qty/total (paling aman)
        location.reload();
      });
      $('#modalProduk').modal('hide');
    }).fail(function(){
      if (window.Swal) Swal.fire({icon:'error', title:'Error', text:'Gagal terhubung ke server'});
      else alert('Gagal terhubung ke server');
    }).always(function(){
      $btn.prop('disabled', false);
    });
  });
})();
</script>

<?php $this->load->view("front_end/footer.php"); ?>
