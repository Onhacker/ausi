<?php $this->load->view("front_end/head.php"); ?>
<div class="container-fluid">

  <!-- Judul -->
  <div class="hero-title" role="banner" aria-label="Judul halaman">
    <h1 class="text">Terima kasih! 🎉</h1>
    <div class="text-muted">Pesanan kamu sudah kami terima.</div>
    <span class="accent" aria-hidden="true"></span>
  </div>

  <div class="col-12">
    <div class="text-center">
      <i class="h1 mdi mdi-chair-school text-muted" aria-hidden="true"></i>
      <h3 class="mb-3">
        <?php if (!empty($meja_info)): ?>
          <span class="badge badge-success">Table: <?= html_escape($meja_info) ?></span>
        <?php else: ?>
          <span class="badge badge-secondary">Mode: Takeaway / Walk-in</span>
        <?php endif; ?>
      </h3>
    </div>
  </div>

<?php
if (!function_exists('tanggal_indo')) {
  function tanggal_indo($datetime, $show_time = true, $tz = 'Asia/Jakarta') {
    if (!$datetime) return '';
    try {
      if (is_numeric($datetime)) {
        $dt = (new DateTime('@'.$datetime))->setTimezone(new DateTimeZone($tz));
      } else {
        $dt = new DateTime($datetime, new DateTimeZone($tz));
      }
    } catch (Exception $e) { return $datetime; }

    $hari  = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

    $h = $hari[(int)$dt->format('w')];
    $d = (int)$dt->format('j');
    $m = $bulan[(int)$dt->format('n')];
    $y = $dt->format('Y');
    $t = $dt->format('H:i');

    return $h.', '.$d.' '.$m.' '.$y.($show_time ? ' '.$t : '');
  }
}

$order_code   = isset($order->kode) ? $order->kode : (isset($order->order_code) ? $order->order_code : (isset($order->invoice) ? $order->invoice : null));
$created_at   = isset($order->created_at) ? $order->created_at : (isset($order->tanggal) ? $order->tanggal : date('Y-m-d H:i:s'));
$created_at_id = tanggal_indo($created_at, true, 'Asia/Makassar');

$customer   = isset($order->customer_name) ? $order->customer_name : (isset($order->nama_pelanggan) ? $order->nama_pelanggan : (isset($customer_name) ? $customer_name : 'Pelanggan'));
$note_text  = isset($order->note) ? $order->note : (isset($note) ? $note : (isset($order->catatan)?$order->catatan:''));

$items      = isset($items) && is_array($items) ? $items : [];
if (!isset($total)) {
  $total = 0;
  foreach ($items as $it) {
    $harga = (int)($it->harga ?? 0);
    $qty   = (int)($it->qty ?? 0);
    $total += $harga * $qty;
  }
}

/** NEW: normalisasi method & bukti_bayar untuk blok transfer */
$method = $this->input->get('method', true) ?: ($order->paid_method ?? null);
$bukti_bayar = $order->bukti_bayar ?? null;
?>

<style>
  #modalReceipt.modal         { z-index: 200001 !important; pointer-events: auto !important; }
  .modal-backdrop             { z-index: 199991 !important; pointer-events: none !important; }
  body.modal-open .wrapper,
  body.modal-open .content-page,
  body.modal-open .container-fluid,
  body.modal-open .page-title-box {
    filter: none !important; transform: none !important; opacity: 1 !important;
  }
  #modalReceipt .modal-dialog{ margin: 1.25rem auto; }
  #modalReceipt .modal-content{
    display:flex; flex-direction:column;
    border:0; border-radius:16px; box-shadow:0 20px 40px rgba(0,0,0,.18);
    max-height: calc(100vh - 2.5rem);
  }
  #modalReceipt .modal-header,#modalReceipt .modal-footer{ border:0; }
  #modalReceipt .modal-body{ flex:1 1 auto; overflow:auto !important; -webkit-overflow-scrolling:touch; }
  @media (max-width: 767.98px){
    #modalReceipt .modal-dialog{ margin:.75rem auto; }
    #modalReceipt .modal-content{ max-height: calc(100vh - 1.5rem); }
  }
</style>

  <!-- Ringkasan Pesanan -->
  <div class="card card-body mb-3">
    <div class="row">
      <div class="col-md-6">
        <h5 class="mb-3">Ringkasan Pesanan</h5>
        <dl class="row mb-0">
          <?php if ($order_code): ?>
          <dt class="col-5 col-sm-4">Kode Pesanan</dt>
          <dd class="col-7 col-sm-8"><code><?= html_escape($order_code) ?></code></dd>
          <?php endif; ?>

          <dt class="col-5 col-sm-4">Waktu</dt>
          <dd class="col-7 col-sm-8"><?= html_escape($created_at_id) ?></dd>

          <dt class="col-5 col-sm-4">Pelanggan</dt>
          <dd class="col-7 col-sm-8"><?= html_escape($customer) ?></dd>

          <?php if (!empty($meja_info)): ?>
          <dt class="col-5 col-sm-4">Tabel</dt>
          <dd class="col-7 col-sm-8"><?= html_escape($meja_info) ?></dd>
          <?php endif; ?>

          <?php if (trim((string)$note_text) !== ''): ?>
          <dt class="col-5 col-sm-4">Catatan</dt>
          <dd class="col-7 col-sm-8"><?= nl2br(html_escape($note_text)) ?></dd>
          <?php endif; ?>
        </dl>
      </div>
      <div class="col-md-6 text-md-right mt-3 mt-md-0">
        <div class="h5 mb-1">Total Pembayaran</div>
        <div class="display-4" style="font-size:1.8rem;">Rp <?= number_format((int)$total,0,',','.') ?></div>
      </div>
    </div>
  </div>

  <!-- List Orderan -->
  <div class="card card-body">
    <h5 class="mb-3">Daftar Item</h5>

    <?php if (empty($items)): ?>
      <div class="text-muted">Tidak ada item.</div>
    <?php else: ?>

      <!-- Tabel (desktop & tablet) -->
      <div class="table-responsive d-none d-md-block">
        <table class="table table-centered table-striped mb-0">
          <thead class="thead-light">
            <tr>
              <th style="width:64px">Gambar</th>
              <th>Produk</th>
              <th class="text-right" style="width:140px">Harga</th>
              <th class="text-center" style="width:120px">Qty</th>
              <th class="text-right" style="width:160px">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($items as $it):
              $img   = !empty($it->gambar) ? (strpos($it->gambar,'http')===0 ? $it->gambar : base_url($it->gambar)) : base_url('assets/images/icon_app.png');
              $nama  = $it->nama ?? $it->produk_nama ?? '-';
              $harga = (int)($it->harga ?? 0);
              $qty   = (int)($it->qty ?? 0);
              $sub   = $harga * $qty;
            ?>
            <tr>
              <td><img src="<?= $img ?>" class="img-fluid rounded" style="width:48px;height:48px;object-fit:cover" alt=""></td>
              <td>
                <?= html_escape($nama) ?>
                <?php if (!empty($it->tambahan) && (int)$it->tambahan === 1): ?>
                  <span class="badge badge-warning ml-1">Tambahan</span>
                <?php endif; ?>
              </td>
              <td class="text-right">Rp <?= number_format($harga,0,',','.') ?></td>
              <td class="text-center"><?= $qty ?></td>
              <td class="text-right">Rp <?= number_format($sub,0,',','.') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <th colspan="4" class="text-right">Total</th>
              <th class="text-right">Rp <?= number_format((int)$total,0,',','.') ?></th>
            </tr>
          </tfoot>
        </table>
      </div>

      <!-- Kartu (mobile) -->
      <div class="d-md-none">
        <?php foreach($items as $it):
          $img   = !empty($it->gambar) ? (strpos($it->gambar,'http')===0 ? $it->gambar : base_url($it->gambar)) : base_url('assets/images/icon_app.png');
          $nama  = $it->nama ?? $it->produk_nama ?? '-';
          $harga = (int)($it->harga ?? 0);
          $qty   = (int)($it->qty ?? 0);
          $sub   = $harga * $qty;
        ?>
        <div class="media p-2 border rounded mb-2">
          <img src="<?= $img ?>" class="mr-3 rounded" style="width:56px;height:56px;object-fit:cover" alt="">
          <div class="media-body">
            <div class="font-weight-600">
              <?= html_escape($nama) ?>
              <?php if (!empty($it->tambahan) && (int)$it->tambahan === 1): ?>
                <span class="badge badge-warning align-middle ml-1">Tambahan</span>
              <?php endif; ?>
            </div>
            <div class="small text-muted mb-1">Harga: Rp <?= number_format($harga,0,',','.') ?></div>
            <div class="d-flex justify-content-between align-items-center">
              <div class="small">Qty: <strong><?= $qty ?></strong></div>
              <div class="small">Subtotal: <strong>Rp <?= number_format($sub,0,',','.') ?></strong></div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>

        <div class="d-flex justify-content-between align-items-center border-top pt-2">
          <div class="font-weight-600">Total</div>
          <div class="font-weight-700">Rp <?= number_format((int)$total,0,',','.') ?></div>
        </div>
      </div>

    <?php endif; ?>
  </div>

  <!-- Aksi -->
  <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-3">
    <a href="<?= site_url('produk') ?>" class="btn btn-outline-secondary">
      <i class="mdi mdi-arrow-left"></i> Menu
    </a>
    <div class="d-flex align-items-center">
      <?php $order_ref = !empty($order->kode) ? $order->kode : (isset($order->id) ? $order->id : null); ?>
      <?php if ($order_ref): ?>
      <button type="button" class="btn btn-danger mr-2" id="btnPreviewReceipt" data-id="<?= (int)$order->id ?>">
        <i class="mdi mdi-printer"></i> Struk
      </button>
      <?php endif; ?>

      <?php if (!in_array($order->status ?? 'pending', ['paid','canceled'], true)): ?>
        <div class="btn-group mr-2" role="group" aria-label="Pembayaran">
          <a class="btn btn-outline-success" href="<?= site_url('produk/pay_cash/'.(int)$order->id) ?>">
            <i class="mdi mdi-cash"></i> Tunai
          </a>
          <a class="btn btn-outline-primary" href="<?= site_url('produk/pay_qris/'.(int)$order->id) ?>">
            <i class="mdi mdi-qrcode-scan"></i> QRIS
          </a>
          <a class="btn btn-outline-info" href="<?= site_url('produk/pay_transfer/'.(int)$order->id) ?>">
            <i class="mdi mdi-bank-transfer"></i> Transfer
          </a>
        </div>
      <?php else: ?>
        <span class="badge badge-success mr-2">
          Sudah dibayar<?= !empty($order->paid_method) ? ' ('.html_escape($order->paid_method).')' : '' ?>
        </span>
      <?php endif; ?>

      <a href="<?= site_url('produk') ?>" class="btn btn-primary">
        Pesan Lagi <i class="mdi mdi-arrow-right ml-1"></i>
      </a>
    </div>
  </div>

  <!-- NEW: Blok upload bukti transfer -->
  <?php if (($method ?? '') === 'transfer' && !in_array($order->status ?? 'pending', ['paid','canceled'], true)): ?>
    <div class="card card-body mb-3">
      <h5 class="mb-2">Pembayaran via Transfer</h5>

      <?php if ($this->session->flashdata('upload_err')): ?>
        <div class="alert alert-danger"><?= html_escape($this->session->flashdata('upload_err')) ?></div>
      <?php endif; ?>
      <?php if ($this->session->flashdata('upload_ok')): ?>
        <div class="alert alert-success"><?= html_escape($this->session->flashdata('upload_ok')) ?></div>
      <?php endif; ?>

      <?php if (empty($bukti_bayar)): ?>
        <p class="text-muted mb-2">Silakan upload bukti transfer (jpg, png, webp, pdf, maks 4MB).</p>
        <form action="<?= site_url('produk/upload_bukti/'.(int)$order->id) ?>"
              method="post" enctype="multipart/form-data" class="form-inline">
          <div class="form-group mr-2 mb-2">
            <input type="file" name="bukti" class="form-control-file" accept="image/*,.pdf" required>
          </div>
          <button type="submit" class="btn btn-primary mb-2">
            <i class="mdi mdi-upload"></i> Upload Bukti
          </button>
        </form>
      <?php else: ?>
        <div class="d-flex align-items-center">
          <div class="mr-3">
            <?php if (preg_match('~\.(png|jpe?g|webp)$~i', $bukti_bayar)): ?>
              <a href="<?= base_url($bukti_bayar) ?>" target="_blank" rel="noopener">
                <img src="<?= base_url($bukti_bayar) ?>" alt="Bukti transfer"
                     style="width:100px;height:100px;object-fit:cover;border-radius:8px;border:1px solid #eee">
              </a>
            <?php else: ?>
              <a href="<?= base_url($bukti_bayar) ?>" target="_blank" rel="noopener" class="btn btn-outline-info">
                Lihat Bukti (PDF)
              </a>
            <?php endif; ?>
          </div>
          <div>
            <div class="mb-1"><strong>Bukti transfer sudah diunggah</strong></div>
            <a href="<?= base_url($bukti_bayar) ?>" target="_blank" rel="noopener">Buka bukti</a>
          </div>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- Modal Preview Struk -->
  <div class="modal fade" id="modalReceipt" tabindex="-1" aria-hidden="true" aria-labelledby="modalReceiptTitle">
    <div class="modal-dialog modal-sm modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 id="modalReceiptTitle" class="modal-title">Struk</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div id="modalReceiptBody" class="modal-body">
          <div class="text-center text-muted py-4">Memuat…</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Assets -->
<script src="<?php echo base_url('assets/admin') ?>/js/vendor.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/app.min.js"></script>
<script>
(function(){
  $('#btnPreviewReceipt').on('click', function(){
    var id = $(this).data('id');
    $('#modalReceiptTitle').text('Struk');
    $('#modalReceiptBody').html('<div class="text-center text-muted py-4">Memuat…</div>');
    $('#modalReceipt').modal('show');

    $.getJSON("<?= site_url('produk/order_receipt_modal'); ?>/"+id)
      .done(function(r){
        if (!r || !r.success) {
          $('#modalReceiptBody').html('<div class="text-danger p-3">Gagal memuat struk.</div>');
          return;
        }
        if (r.title) $('#modalReceiptTitle').text(r.title);
        $('#modalReceiptBody').html(r.html);
      })
      .fail(function(){
        $('#modalReceiptBody').html('<div class="text-danger p-3">Koneksi bermasalah.</div>');
      });
  });
})();
</script>
<script>
(function(){
  var $m = $('#modalReceipt'); if ($m.length) $m.appendTo('body');
  window.killMasks = function () {
    $('.window-mask, .messager-mask, .datagrid-mask, .easyui-mask, .mm-wrapper__blocker')
      .css('pointer-events','none').hide();
  };
  $('#modalReceipt')
    .on('show.bs.modal', function(){
      if ($('.swal2-container:visible').length) { try { Swal.close(); } catch(e){} }
      window.killMasks && window.killMasks();
    })
    .on('shown.bs.modal', function(){
      window.killMasks && window.killMasks();
      var tries = 0, iv = setInterval(function(){
        window.killMasks && window.killMasks();
        if (++tries > 15) clearInterval(iv);
      }, 120);
      $(this).data('maskIv', iv);
    })
    .on('hide.bs.modal', function(){
      var iv = $(this).data('maskIv'); if (iv) clearInterval(iv);
    });
})();
</script>

<?php $this->load->view("front_end/footer.php"); ?>
