<?php $this->load->view("front_end/head.php"); ?>
<div class="container-fluid">

  <div class="hero-title mb-3">
    <h1 class="text"><?php echo $title ?></h1>
    <div class="text-muted">Silakan transfer sesuai nominal lalu unggah bukti pembayaran.</div>
    <span class="accent" aria-hidden="true"></span>
  </div>

  <?php if ($this->session->flashdata('msg_err')): ?>
    <div class="alert alert-danger"><?= $this->session->flashdata('msg_err'); ?></div>
  <?php endif; ?>
  <?php if ($this->session->flashdata('msg_ok')): ?>
    <div class="alert alert-success"><?= $this->session->flashdata('msg_ok'); ?></div>
  <?php endif; ?>

  <?php
    $order_code = $order->nomor ?? ($order->kode ?? $order->id);
    $total_nom  = (int)$total;
  ?>

  <div class="row">
    <div class="col-lg-7">
      <div class="card card-body mb-3">
        <h5 class="mb-3">Instruksi Transfer</h5>
        <ol class="mb-0">
          <li>Transfer tepat sejumlah: <strong>Rp <?= number_format($total_nom,0,',','.') ?></strong></li>
          <li>Berikan berita/keterangan: <code>ORDER <?= html_escape($order_code) ?></code></li>
          <li>Pilih salah satu rekening di samping.</li>
          <li>Setelah transfer, unggah bukti pada form di bawah.</li>
        </ol>
      </div>

      <div class="card card-body mb-3">
        <h5 class="mb-3">Unggah Bukti Transfer</h5>
        <form method="post" action="<?= site_url('produk/pay_transfer_upload/'.(int)$order->id) ?>" enctype="multipart/form-data">
          <div class="form-group">
            <label for="bukti">File bukti (JPG/PNG/GIF/WEBP/HEIC atau PDF)</label>
            <input type="file" class="form-control" id="bukti" name="bukti" required>
          </div>
          <button class="btn btn-primary"><i class="mdi mdi-upload"></i> Unggah</button>
          <a class="btn btn-light" href="<?= site_url('produk/order_success/'.(int)$order->id) ?>">Kembali</a>
        </form>
      </div>

      <?php if (!empty($order->catatan)): ?>
      <div class="card card-body mb-3">
        <h6 class="mb-2">Catatan Pesanan</h6>
        <div class="small"><?= nl2br(html_escape($order->catatan)) ?></div>
      </div>
      <?php endif; ?>
    </div>

    <div class="col-lg-5">
      <div class="card card-body mb-3">
        <h5 class="mb-3">Rincian Pesanan</h5>
        <dl class="row mb-0">
          <dt class="col-5">Kode</dt>
          <dd class="col-7"><code><?= html_escape($order_code) ?></code></dd>
          <dt class="col-5">Total</dt>
          <dd class="col-7 font-weight-700">Rp <?= number_format($total_nom,0,',','.') ?></dd>
          <?php if (!empty($meja_info)): ?>
            <dt class="col-5">Meja</dt>
            <dd class="col-7"><?= html_escape($meja_info) ?></dd>
          <?php endif; ?>
        </dl>
      </div>

      <div class="card card-body">
        <h5 class="mb-3">Rekening Tujuan</h5>
        <?php foreach(($bank_list ?? []) as $b): ?>
          <div class="border rounded p-2 mb-2">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="font-weight-600"><?= html_escape($b['bank']) ?></div>
                <div class="small text-muted">a.n. <?= html_escape($b['atas_nama']) ?></div>
              </div>
              <div class="text-right">
                <div class="font-weight-700"><?= html_escape($b['no_rek']) ?></div>
                <button class="btn btn-sm btn-outline-secondary mt-1"
                        onclick="navigator.clipboard.writeText('<?= html_escape($b['no_rek']) ?>');this.innerText='Disalin';setTimeout(()=>this.innerText='Salin',1500);">
                  Salin
                </button>
              </div>
            </div>
          </div>
        <?php endforeach; ?>

        <?php if (empty($bank_list)): ?>
          <div class="text-muted">Belum ada rekening di-set. Silakan atur di controller.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

</div>
<?php $this->load->view("front_end/footer.php"); ?>
