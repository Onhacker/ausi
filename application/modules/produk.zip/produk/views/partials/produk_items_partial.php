<?php if (empty($products)): ?>
  <div class="col-12">
    <div class="alert alert-info">Tidak ada produk yang cocok.</div>
  </div>
<?php else: ?>
  <?php foreach ($products as $p):
    $img = $p->gambar
      ? (strpos($p->gambar, 'http') === 0 ? $p->gambar : base_url($p->gambar))
      : base_url('assets/images/products/no-image.png');
    $stok    = (int)($p->stok ?? 0);
    $satuan  = $p->satuan ?: 'pcs';
    $katNama = $p->kategori_nama ?: '';
    $slug    = $p->link_seo;
    $soldout = ($stok === 0);
  ?>
  <div class="col-md-6 col-xl-3">
    <div class="card-box product-box">

      <div class="product-img-bg position-relative">
        <a href="javascript:void(0)" class="btn-detail d-block" data-slug="<?= html_escape($slug); ?>">
          <img src="<?= $img; ?>" alt="<?= html_escape($p->nama); ?>" class="img-fluid"
               style="width:100%;height:200px;object-fit:cover;border-radius:6px;">
        </a>
        <?php if ($soldout): ?>
          <span class="badge badge-danger" style="position:absolute;top:10px;left:10px">Sold Out</span>
        <?php endif; ?>
      </div>

      <div class="product-info">
        <div class="row align-items-center">
          <div class="col">
            <h5 class="font-16 mt-0 sp-line-1 mb-1">
              <a href="javascript:void(0)" class="text-dark btn-detail" data-slug="<?= html_escape($slug); ?>">
                <?= html_escape($p->nama); ?>
              </a>
            </h5>
            <div class="text-muted small mb-1">
              <?= html_escape($katNama); ?>
              <?php if ($soldout): ?>
                <span class="badge badge-danger ml-1">Sold Out</span>
              <?php endif; ?>
            </div>
            <h6 class="m-0">
              <span class="text-muted">Stok : <?= $stok; ?> <?= html_escape($satuan); ?></span>
            </h6>
          </div>
          <div class="col-auto">
            <div class="product-price-tag">Rp <?= number_format((float)$p->harga, 0, ',', '.'); ?></div>
          </div>
        </div>

        <div class="mt-2 d-flex">
          <button type="button"
                  class="btn btn-light btn-sm mr-2 btn-detail"
                  data-slug="<?= html_escape($slug); ?>">
            Detail
          </button>
          <button type="button"
                  class="btn btn-success btn-sm btn-add-cart"
                  data-id="<?= (int)$p->id; ?>"
                  data-qty="1"
                  <?= $soldout ? 'disabled' : ''; ?>>
            <i class="mdi mdi-cart"></i> Keranjang
          </button>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
<?php endif; ?>
