<?php if ($total_pages > 1): ?>
  <div class="col-12">
    <ul class="pagination pagination-rounded justify-content-end mb-3">
      <li class="page-item <?= ($page<=1?'disabled':''); ?>">
        <a href="#" class="page-link" data-page="<?= $page-1; ?>" aria-label="Previous">
          <span aria-hidden="true">«</span><span class="sr-only">Previous</span>
        </a>
      </li>
      <?php for ($i=1;$i<=$total_pages;$i++): ?>
        <li class="page-item <?= ($i==$page?'active':''); ?>">
          <a href="#" class="page-link" data-page="<?= $i; ?>"><?= $i; ?></a>
        </li>
      <?php endfor; ?>
      <li class="page-item <?= ($page>=$total_pages?'disabled':''); ?>">
        <a href="#" class="page-link" data-page="<?= $page+1; ?>" aria-label="Next">
          <span aria-hidden="true">»</span><span class="sr-only">Next</span>
        </a>
      </li>
    </ul>
  </div>
<?php endif; ?>
