<?php
$img = $product->gambar
  ? (strpos($product->gambar, 'http') === 0 ? $product->gambar : base_url($product->gambar))
  : base_url('assets/images/products/no-image.png');

$stok    = (int)($product->stok ?? 0);
$satuan  = $product->satuan ?: 'pcs';
$sku     = $product->sku ?: '-';
$katNama = $product->kategori_nama ?: '';
?>
<div class="row">
  <div class="col-md-5 mb-3 mb-md-0">
    <img src="<?= $img; ?>" alt="<?= html_escape($product->nama); ?>" class="img-fluid rounded"
         style="width:100%;height:auto;object-fit:cover;">
  </div>

  <div class="col-md-7">
    <?php if ($katNama): ?>
      <div class="text-primary mb-1"><?= html_escape($katNama); ?></div>
    <?php endif; ?>

    <h4 class="mb-2"><?= html_escape($product->nama); ?></h4>

    <div class="d-flex align-items-center mb-2">
      <span class="mr-3">SKU: <code><?= html_escape($sku); ?></code></span>
      <?php if ($stok > 0): ?>
        <span class="badge badge-success">Instock</span>
      <?php else: ?>
        <span class="badge badge-danger">Sold Out</span>
      <?php endif; ?>
    </div>

    <h4 class="mb-3">Rp <?= number_format((float)$product->harga, 0, ',', '.'); ?></h4>

    <div class="mb-3" style="max-height:160px;overflow:auto;">
      <?= $product->deskripsi ?: '<p class="text-muted m-0">Belum ada deskripsi.</p>'; ?>
    </div>

    <div class="form-inline mb-3">
      <label class="my-1 mr-2 d-none d-md-inline" for="qty-modal">Qty</label>
      <select class="custom-select my-1 mr-sm-3" id="qty-modal">
        <?php for($i=1; $i<=10; $i++): ?>
          <option value="<?= $i; ?>"><?= $i; ?></option>
        <?php endfor; ?>
      </select>
      <span class="text-muted">Stok: <?= $stok; ?> <?= html_escape($satuan); ?></span>
    </div>

    <div>
      <button type="button"
              class="btn btn-success"
              id="btn-add-cart-modal"
              data-id="<?= (int)$product->id; ?>"
              <?= $stok <= 0 ? 'disabled' : ''; ?>>
        <i class="mdi mdi-cart"></i> Tambah ke Keranjang
      </button>
    </div>
  </div>
</div>
