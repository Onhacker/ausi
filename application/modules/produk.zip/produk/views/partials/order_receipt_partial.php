<?php
if (!function_exists('tanggal_indo')) {
  function tanggal_indo($datetime, $show_time = true, $tz = 'Asia/Jakarta') {
    if (!$datetime) return '';
    try {
      // Support string "Y-m-d H:i:s" / "Y-m-d" / timestamp int
      if (is_numeric($datetime)) {
        $dt = (new DateTime('@'.$datetime))->setTimezone(new DateTimeZone($tz));
      } else {
        $dt = new DateTime($datetime, new DateTimeZone($tz));
      }
    } catch (Exception $e) { return $datetime; }

    $hari  = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

    $h = $hari[(int)$dt->format('w')];
    $d = (int)$dt->format('j');
    $m = $bulan[(int)$dt->format('n')];
    $y = $dt->format('Y');
    $t = $dt->format('H:i');

    return $h.', '.$d.' '.$m.' '.$y.($show_time ? ' '.$t : '');
  }
}
// Helper mini
$fmt = fn($n) => 'Rp '.number_format((int)$n,0,',','.');
$site = isset($rec->nama_website) ? $rec->nama_website : 'Toko';
$alamat = isset($rec->alamat) ? $rec->alamat : '';
$telp   = isset($rec->telepon) ? $rec->telepon : '';
$kode   = $order->nomor ?? ($order->kode ?? $order->id);
$waktu  = $order->created_at ?? date('Y-m-d H:i:s');
$waktu = tanggal_indo($waktu);
$pelanggan = $order->nama ?? ($order->customer_name ?? 'Pelanggan');
?>
<style>
/* ============ SCREEN PREVIEW ============ */
.receipt-wrap{
  max-width: 340px; margin:0 auto; background:#fff; color:#111;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
  font-size: 12px; line-height: 1.35; border:1px dashed #e5e7eb; border-radius:8px; padding:12px;
}
.receipt-center{ text-align:center; }
.receipt-title{ font-weight:700; font-size:14px; }
.receipt-muted{ color:#6b7280; }
.receipt-hr{ border:0; border-top:1px dashed #cfd4dc; margin:8px 0; }
.receipt-row{ display:flex; }
.receipt-row .left{ flex:1; }
.receipt-row .right{ margin-left:8px; white-space:nowrap; }
.receipt-items{ width:100%; border-collapse:collapse; }
.receipt-items th,.receipt-items td{ padding:3px 0; }
.receipt-items th{ text-align:left; font-weight:700; border-bottom:1px dashed #cfd4dc; }
.text-right{ text-align:right; }
.text-center{ text-align:center; }
.tot{ font-weight:700; font-size:13px; }
.small{ font-size:11px; }

/* ============ PRINT ============ */
@media print {
  @page { size: 80mm auto; margin: 0; }
  body *{ visibility:hidden; }
  .printable-receipt, .printable-receipt *{ visibility:visible; }
  .printable-receipt{ position:absolute; left:0; top:0; width:80mm; padding:0; border:0; }
  .receipt-wrap{ border:0; border-radius:0; max-width:unset; width:80mm; }
}
</style>

<div class="printable-receipt">
  <div class="receipt-wrap">
    <div class="receipt-center">
      <div class="receipt-title"><?= html_escape($site) ?></div>
      <?php if ($alamat): ?><div class="small receipt-muted"><?= nl2br(html_escape($alamat)) ?></div><?php endif; ?>
      <?php if ($telp): ?><div class="small receipt-muted">Telp: <?= html_escape($telp) ?></div><?php endif; ?>
    </div>

    <hr class="receipt-hr">

    <div class="receipt-row small">
      <div class="left">Kode</div><div class="right"><strong>#<?= html_escape($kode) ?></strong></div>
    </div>
    <div class="receipt-row small">
      <div class="left">Waktu</div><div class="right"><?= html_escape($waktu) ?></div>
    </div>
    <div class="receipt-row small">
      <div class="left">Pelanggan</div><div class="right"><?= html_escape($pelanggan) ?></div>
    </div>
    <?php if (!empty($meja_info)): ?>
    <div class="receipt-row small">
      <div class="left">Meja</div><div class="right"><?= html_escape($meja_info) ?></div>
    </div>
    <?php endif; ?>

    <?php if (!empty($order->catatan)): ?>
      <div class="small" style="margin-top:6px;">Catatan: <?= nl2br(html_escape($order->catatan)) ?></div>
    <?php endif; ?>

    <hr class="receipt-hr">

    <table class="receipt-items">
      <thead>
        <tr>
          <th>Item</th>
          <th class="text-center" style="width:36px;">Qty</th>
          <th class="text-right" style="width:90px;">Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $it):
          $nama = $it->nama ?? $it->produk_nama ?? '-';
          $qty  = (int)($it->qty ?? 0);
          $harga= (int)($it->harga ?? 0);
          $sub  = $qty * $harga;
        ?>
        <tr>
          <td>
            <?= html_escape($nama) ?><br>
            <span class="small receipt-muted">@ <?= $fmt($harga) ?></span>
          </td>
          <td class="text-center"><?= $qty ?></td>
          <td class="text-right"><?= $fmt($sub) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><td colspan="3"><hr class="receipt-hr"></td></tr>
        <tr>
          <td class="tot">TOTAL</td>
          <td></td>
          <td class="text-right tot"><?= $fmt($total) ?></td>
        </tr>
      </tfoot>
    </table>

    <hr class="receipt-hr">
    <div class="receipt-center small">Terima kasih 🙏</div>
  </div>
</div>
