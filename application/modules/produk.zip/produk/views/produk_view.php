<?php $this->load->view("front_end/head.php"); ?>
<div class="container-fluid">
<div class="hero-title" role="banner" aria-label="Judul situs">
    <h1 class="text">Menu</h1>
    <span class="accent" aria-hidden="true"></span>
  </div>
  <!-- page title -->
 

  <!-- toolbar: search + kategori + sort (no Add New) -->
  <div class="row">
    <div class="col-12">
      <div class="card-box">

  <!-- CSS kecil untuk layout responsif -->
  <style>
    .filter-toolbar{
      display:flex; flex-wrap:wrap; align-items:center; gap:.5rem;
    }
    .filter-toolbar .form-group{ margin-bottom:.5rem; }
    .filter-toolbar .cart-wrap{ margin-left:auto; }
    /* Mobile: stack ke bawah + sembunyikan label */
    @media (max-width: 767.98px){
      .filter-toolbar .form-group{ width:100%; }
      .filter-toolbar label{ display:none; }         /* sembunyikan label di mobile */
      .filter-toolbar .btn{ width:100%; }            /* tombol full width di mobile */
      .filter-toolbar .cart-wrap{ width:100%; order:99; } /* keranjang pindah ke bawah */
    }
    /* Group kanan: keranjang + badge meja */
.meta-wrap{
  display:flex; align-items:center; gap:.5rem;
}

/* Mobile: form tetap stack ke bawah, tapi keranjang & meja satu baris */
@media (max-width: 767.98px){
  .filter-toolbar{ flex-direction:column; align-items:stretch; }

  .filter-form{ width:100%; }
  .filter-form .form-group{ width:100%; margin-right:0 !important; }

  .meta-wrap{
    width:100%;
    display:flex;
    justify-content:space-between; /* jarak kiri-kanan */
    align-items:center;
  }

  /* Pastikan tombol cart tidak membentang penuh */
  .meta-wrap .btn-cart{ width:auto; }

  /* Supaya badge meja tidak turun baris */
  .meta-wrap .meja-badge{
    white-space:nowrap;
  }
}
/* ===== Equal width + equal height untuk dua tombol ===== */
.meta-wrap{
  display: grid;
  grid-auto-flow: column;        /* setiap anak = kolom */
  grid-auto-columns: 1fr;        /* lebar sama (1fr) */
  gap: .5rem;                    /* jarak antar tombol */
  margin-left: auto;             /* dorong ke kanan di desktop */
  width: 100%;
  max-width: 560px;              /* biar nggak terlalu panjang di desktop */
}

.eq-btn{
  display: flex; align-items: center; justify-content: center;
  min-height: 44px;              /* tinggi seragam */
  padding: .55rem .75rem;
  border-radius: 12px;
  white-space: nowrap;           /* teks tidak turun baris */
}

/* Badge meja selaras dengan badge cart */
.meja-badge{
  background:#10b981; color:#fff; font-weight:700; font-size:.75rem; line-height:1;
  padding:.25rem .45rem; border-radius:999px;
  box-shadow:0 4px 10px rgba(16,185,129,.35);
}

/* Responsif: tetap 2 kolom saat ada 2 tombol, 1 kolom bila cuma 1 tombol */
@media (max-width: 767.98px){
  .meta-wrap{ width: 100%; max-width: none; }
}


  </style>

 <div class="filter-toolbar">
  <!-- FORM FILTER -->
  <form id="filter-form" class="filter-form d-flex align-items-center flex-wrap mb-0">
    <div class="form-group mb-2 mr-2 flex-grow-1 minw-220">
      <div class="input-group input-group-flat">
        <div class="input-group-prepend">
          <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
        </div>
        <input type="search" class="form-control filter-input"
               id="q" name="q" value="<?= html_escape($q); ?>"
               placeholder="Cari produk…"
               aria-label="Cari produk">
      </div>
    </div>

    <div class="form-group mb-2 mr-2">
      <select class="custom-select filter-select" id="kategori" name="kategori" aria-label="Kategori">
        <option value="">Semua Kategori</option>
        <?php foreach($kategoris as $k): ?>
          <option value="<?= (int)$k->id; ?>" <?= ((string)$kategori === (string)$k->id ? 'selected' : ''); ?>>
            <?= html_escape($k->nama); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-group mb-2 mr-2">
      <select class="custom-select filter-select" id="sort" name="sort" aria-label="Urutkan">
        <option value="new"        <?= $sort==='new'?'selected':''; ?>>Terbaru</option>
        <option value="price_low"  <?= $sort==='price_low'?'selected':''; ?>>Harga Rendah</option>
        <option value="price_high" <?= $sort==='price_high'?'selected':''; ?>>Harga Tinggi</option>
        <option value="sold_out"   <?= $sort==='sold_out'?'selected':''; ?>>Sold Out</option>
      </select>
    </div>

    <div class="form-group mb-2">
      <button type="button" id="btn-apply" class="btn btn-blue mr-2">
        <i class="mdi mdi-filter-variant mr-1"></i> Terapkan
      </button>
      <button type="button" id="btn-reset" class="btn btn-light btn-white mt-1">Reset</button>
    </div>
  </form>

 <div class="meta-wrap">
  <!-- Keranjang -->
  <a href="<?= site_url('produk/cart') ?>" class="btn btn-outline-danger btn-cart eq-btn" aria-label="Buka keranjang">
  <i class="mdi mdi-cart-outline mr-1" aria-hidden="true"></i>
  <span class="d-none d-md-inline">Keranjang</span>&nbsp;
  (<span class="cart-badge" id="cart-count">0</span>)
</a>


  <?php if (!empty($meja_info)): ?>
  <!-- Meja -->
  <a href="javascript:void(0)" class="btn btn-outline-success btn-meja eq-btn" aria-label="Info meja" title="Pesanan untuk meja ini">
    <i class="mdi mdi-table-chair mr-1" aria-hidden="true"></i>
    <span class="d-none d-md-inline">Meja</span>&nbsp;
    (<span class="meja-badge"><?= html_escape($meja_info) ?></span>)
  </a>
  <?php endif; ?>
</div>



    <style type="text/css">
      /* Warna biru andalan */
    .btn-outline-blue{
      color:#1e88e5; border:1px solid #1e88e5; background:transparent;
      position:relative; overflow:hidden; transition:all .2s ease;
    }
    .btn-outline-blue:hover{ background:#1e88e5; color:#fff; box-shadow:0 6px 18px rgba(30,136,229,.25); }
    .btn-outline-blue:active{ transform: translateY(1px); }

    .btn-cart .mdi{ font-size:18px; line-height:1; }

    /* Badge jumlah item menempel di pojok tombol */
    .badge-blue{
      background:#1e88e5; color:#fff;
    }
    .btn-cart .badge-count{
      position:absolute; top:-8px; right:-8px; min-width:22px; height:22px;
      padding:4px 6px; border-radius:14px; font-weight:600; font-size:12px;
      display:inline-flex; align-items:center; justify-content:center;
      box-shadow:0 4px 12px rgba(30,136,229,.35);
    }

    /* Mobile tweaks: tombol full, teks disembunyikan (badge & ikon tetap tampil) */
    @media (max-width: 767.98px){
      .btn-cart{ width:100%; justify-content:center; }
    }

    </style>

  </div>

</div>

    </div>
  </div>

  <!-- GRID & PAGINATION (AJAX target) -->
  <div class="row" id="grid-products">
    <!-- items injected via AJAX -->
  </div>

  <div class="row">
    <div class="col-12" id="pagination-wrap">
      <!-- pagination injected via AJAX -->
    </div>
  </div>

</div>


  <style>
  /* Modal Produk – base */
  #modalProduk.modal            { z-index: 200001 !important; pointer-events: auto !important; }
  .modal-backdrop               { z-index: 199991 !important; pointer-events: none !important; }
  #modalProduk .modal-content   { border:0; border-radius:16px; box-shadow:0 20px 40px rgba(0,0,0,.18); }
  #modalProduk .modal-header,
  #modalProduk .modal-footer    { border:0; }
  /* Matikan efek blur/transform apa pun yang “nempel” ke modal */
  /*#modalProduk, #modalProduk .modal-dialog, #modalProduk .modal-content {
    filter:none !important; -webkit-filter:none !important;
    transform:none !important; -webkit-transform:none !important; opacity:1 !important;
  }*/
  /* Saat modal terbuka, jangan blur parent2 layout */
  /*body.modal-open .wrapper,*/
  /*body.modal-open .content-page,*/
  /*body.modal-open .container-fluid,*/
  /*body.modal-open .page-title-box { filter:none !important; -webkit-filter:none !important; transform:none !important; opacity:1 !important; }*/

  /* (opsional) blur latar di backdrop—modal tetap tajam */
  /*.modal-backdrop.show { opacity:.35; backdrop-filter: blur(3px); }*/
  /* ===== Modal Produk: scroll hanya di body ===== */
#modalProduk .modal-dialog{
  margin: 1.25rem auto;                 /* ruang atas-bawah */
  height: auto !important;              /* cegah tinggi 100% dari tema */
  max-height: none !important;
}

#modalProduk .modal-content{
  display: flex; flex-direction: column; 
  /* batasi tinggi agar muat layar; sisakan margin untuk header/footer */
  max-height: calc(100vh - 2.5rem);
  border: 0; border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,.18);
}

#modalProduk .modal-header,
#modalProduk .modal-footer{
  flex: 0 0 auto; border: 0;
}

#modalProduk .modal-body{
  flex: 1 1 auto;
  overflow: auto !important;            /* ← scroll di sini */
  -webkit-overflow-scrolling: touch;    /* smooth di iOS */
  max-height: none !important;          /* jangan dibatasi selain oleh .modal-content */
}

/* Gambar di modal jangan narik tinggi dialog */
#modalProduk .modal-body img{
  max-width: 100%; height: auto;
  max-height: 60vh;                     /* cukup besar, tetap muat layar */
  object-fit: contain;
}

/* Mobile: sedikit lebih rapat, tapi tetap scroll saat perlu */
@media (max-width: 767.98px){
  #modalProduk .modal-dialog{ margin: .75rem auto; }
  #modalProduk .modal-content{ max-height: calc(100vh - 1.5rem); }
}


</style>

<!-- PRODUCT MODAL -->
<!-- MODAL PRODUK -->
<div class="modal fade" id="modalProduk" tabindex="-1" aria-hidden="true" aria-labelledby="modalProdukTitle">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="modalProdukTitle" class="modal-title">Detail Produk</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Tutup"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body" id="modalProdukBody">
        <div class="text-center py-5 text-muted">Memuat…</div>
      </div>
    </div>
  </div>
</div>




<script src="<?php echo base_url('assets/admin') ?>/js/vendor.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/app.min.js"></script>
<script src="<?php echo base_url('assets/admin') ?>/js/sw.min.js"></script>
<?php $this->load->view("front_end/footer.php") ?>
<?php if ($this->session->flashdata('cart_reset_msg')): ?>
<script>
  // info ke user
  if (window.Swal) {
    Swal.fire({icon:'info', title:'Keranjang direset', text:'<?= addslashes($this->session->flashdata('cart_reset_msg')); ?>'});
  }
  // pastikan badge langsung 0 tanpa nunggu AJAX
  document.addEventListener('DOMContentLoaded', function(){
    var el = document.getElementById('cart-count');
    if (el) el.textContent = '0';
  });
</script>
<?php endif; ?>

<script>
(function(){
  const $grid = $('#grid-products');
  const $pagi = $('#pagination-wrap');
  const $form = $('#filter-form');
  const $cartCount = $('#cart-count');

  function serializeFilters(page=1){
    const q = $('#q').val() || '';
    const kategori = $('#kategori').val() || '';
    const sort = $('#sort').val() || 'new';
    const per_page = 12;
    return { q, kategori, sort, page, per_page };
  }

  function loading(on=true){
    const loader = '<div class="col-12 text-center py-5" id="loader">Memuat...</div>';
    if (on){
      $grid.html(loader);
      $pagi.html('');
    } else {
      $('#loader').remove();
    }
  }

  // Load products via AJAX
  function loadProducts(page=1, pushUrl=true){
    loading(true);
    const params = serializeFilters(page);
    $.getJSON("<?= site_url('produk/list_ajax'); ?>", params)
      .done(function(r){
        if (!r || !r.success){ $grid.html('<div class="col-12 alert alert-danger">Gagal memuat data.</div>'); return; }
        $grid.html(r.items_html);
        $pagi.html(r.pagination_html);
        if (pushUrl){
          const url = new URL(window.location.href);
          url.searchParams.set('q', params.q);
          url.searchParams.set('kategori', params.kategori);
          url.searchParams.set('sort', params.sort);
          url.searchParams.set('page', r.page);
          history.pushState(params, '', url.toString());
        }
        bindAddToCart();     // re-bind after replace
        bindPagination(); 
        bindDetailModal();   // re-bind after replace
      })
      .fail(function(){
        $grid.html('<div class="col-12 alert alert-danger">Koneksi bermasalah.</div>');
      });
  }

  function bindPagination(){
    // handle click on <a data-page="x">
    $('#pagination-wrap').off('click', 'a[data-page]').on('click', 'a[data-page]', function(e){
      e.preventDefault();
      const p = parseInt($(this).data('page') || 1);
      loadProducts(p);
    });
  }

  function bindAddToCart(){
    // add-to-cart buttons
    $('#grid-products').off('click', '.btn-add-cart').on('click', '.btn-add-cart', function(e){
      e.preventDefault();
      const id  = $(this).data('id');
      const qty = parseInt($(this).data('qty') || 1);
      $.ajax({
        url: "<?= site_url('produk/add_to_cart'); ?>",
        type: "POST",
        dataType: "json",
        data: { id, qty },
      }).done(function(r){
        if (!r.success){ notifyError(r.pesan || 'Gagal menambahkan'); return; }
        $cartCount.text(r.count);
        notifySuccess('Ditambahkan ke keranjang');
      }).fail(function(){ notifyError('Gagal terhubung ke server'); });

    });
  }

  function loadCartCount(){
    $.getJSON("<?= site_url('produk/cart_count'); ?>")
      .done(function(r){ if (r && r.success){ $cartCount.text(r.count); }});
  }

  // Form interactions
  $('#btn-apply').on('click', function(){
    loadProducts(1);
  });
  $('#btn-reset').on('click', function(){
    $('#q').val(''); $('#kategori').val(''); $('#sort').val('new');
    loadProducts(1);
  });

  // Auto-search on Enter
  $('#q').on('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); loadProducts(1); }});

  // Initial load
  $(document).ready(function(){
    loadCartCount();
    // if URL has query (q/kategori/sort/page) it will be picked up by server once we pass it;
    // but we read current form only; so parse URL first:
    const url = new URL(window.location.href);
    if (url.searchParams.has('q')) $('#q').val(url.searchParams.get('q'));
    if (url.searchParams.has('kategori')) $('#kategori').val(url.searchParams.get('kategori'));
    if (url.searchParams.has('sort')) $('#sort').val(url.searchParams.get('sort'));
    const firstPage = parseInt(url.searchParams.get('page') || '1');
    loadProducts(firstPage, false);
  });

  // Handle back/forward
  window.addEventListener('popstate', function(e){
    const s = e.state || {};
    $('#q').val(s.q || ''); $('#kategori').val(s.kategori || ''); $('#sort').val(s.sort || 'new');
    loadProducts(parseInt(s.page || 1), false);
  });

})();


function bindDetailModal(){
  // pastikan modal tidak di dalam container yg ter-blur
  var $m = $('#modalProduk'); if ($m.length) $m.appendTo('body');

  // lifecycle modal → bersihkan masker
  $('#modalProduk')
    .on('show.bs.modal', function(){ window.killMasks && window.killMasks(); })
    .on('shown.bs.modal', function(){
      window.killMasks && window.killMasks();
      // beberapa lib suka spawn masker lagi → bersihkan sebentar
      var tries = 0, iv = setInterval(function(){
        window.killMasks && window.killMasks();
        if (++tries > 15) clearInterval(iv);
      }, 120);
      $(this).data('maskIv', iv);
    })
    .on('hide.bs.modal', function(){
      var iv = $(this).data('maskIv'); if (iv) clearInterval(iv);
    });

  // buka modal & load konten
  $('#grid-products').off('click', '.btn-detail').on('click', '.btn-detail', function(e){
    e.preventDefault();
    const slug = $(this).data('slug');
    $('#modalProdukTitle').text('Detail Produk');
    $('#modalProdukBody').html('<div class="text-center py-5 text-muted">Memuat…</div>');
    $('#modalProduk').modal('show');

    $.getJSON("<?= site_url('produk/detail_modal'); ?>", { slug: slug })
      .done(function(r){
        if (!r || !r.success){ $('#modalProdukBody').html('<div class="text-danger p-3">Gagal memuat detail.</div>'); return; }
        if (r.title) $('#modalProdukTitle').text(r.title);
        $('#modalProdukBody').html(r.html);
      })
      .fail(function(){
        $('#modalProdukBody').html('<div class="text-danger p-3">Koneksi bermasalah.</div>');
      });
  });

  // Tambah ke keranjang dari dalam modal (delegation)
$('#modalProduk').off('click', '#btn-add-cart-modal').on('click', '#btn-add-cart-modal', function(e){
  e.preventDefault();

  const $btn = $(this);
  const id   = $btn.data('id');
  const qty  = parseInt($('#qty-modal').val() || 1);

  // cegah double-click
  $btn.prop('disabled', true);

  $.ajax({
    url: "<?= site_url('produk/add_to_cart'); ?>",
    type: "POST",
    dataType: "json",
    data: { id, qty },
  }).done(function(r){
    if (!r || !r.success){
      notifyError((r && r.pesan) || 'Gagal menambahkan');
      return;
    }
    $('#cart-count').text(r.count);

    // TUTUP MODAL lebih dulu, lalu tampilkan notifikasi sukses
    $('#modalProduk').one('hidden.bs.modal', function(){
      notifySuccess('Ditambahkan ke keranjang');
    });
    $('#modalProduk').modal('hide');
  }).fail(function(){
    notifyError('Gagal terhubung ke server');
  }).always(function(){
    $btn.prop('disabled', false);
  });
});

}
</script>


<script>
  // Helper notifikasi
  function notifySuccess(msg){
    if (window.Swal) {
      Swal.fire({ icon:'success', title:'Berhasil', text: msg, timer:1400, showConfirmButton:false });
    } else { alert(msg); }
  }
  function notifyError(msg){
    if (window.Swal) {
      Swal.fire({ icon:'error', title:'Gagal', text: msg });
    } else { alert(msg); }
  }
</script>
<script>

  window.killMasks = function () {
    $('.window-mask, .messager-mask, .datagrid-mask, .easyui-mask, .mm-wrapper__blocker')
      .css('pointer-events','none').hide();
  };
</script>

