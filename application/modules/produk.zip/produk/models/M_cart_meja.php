<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_cart_meja extends CI_Model {

    public function __construct(){
        parent::__construct();
    }

    /** Cari atau buat cart 'open' untuk meja tertentu. Return row (id, dll). */
    public function ensure_open_cart($meja_kode){
        $meja_kode = trim($meja_kode);
        if ($meja_kode === '') return null;

        // Coba ambil yang open
        $row = $this->db->get_where('cart_meja', ['meja_kode'=>$meja_kode, 'status'=>'open'])->row();
        if ($row) return $row;

        // Buat baru
        $ok = $this->db->insert('cart_meja', [
            'meja_kode' => $meja_kode,
            'status'    => 'open',
        ]);
        if (!$ok) return null;

        $id = $this->db->insert_id();
        return $this->db->get_where('cart_meja', ['id'=>$id])->row();
    }

    /** Tambahkan/increment item (ON DUPLICATE → qty += $qty). */
   public function add_item($cart_id, $produk_id, $qty, $harga){
        $sql = "INSERT INTO cart_meja_item (cart_id, produk_id, qty, harga)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE qty = qty + VALUES(qty), harga = VALUES(harga), updated_at = CURRENT_TIMESTAMP()";
        return $this->db->query($sql, [(int)$cart_id, (int)$produk_id, max(1,(int)$qty), (int)$harga]);
    }

    /** SET qty absolut (bukan increment). Jika qty<=0 → delete. */
    public function set_qty($cart_id, $produk_id, $qty, $harga_snapshot=null){
        $cart_id   = (int)$cart_id;
        $produk_id = (int)$produk_id;
        $qty       = (int)$qty;

        if ($qty <= 0) {
            return $this->db->delete('cart_meja_item', ['cart_id'=>$cart_id, 'produk_id'=>$produk_id]);
        }
        $harga = ($harga_snapshot !== null) ? (int)$harga_snapshot : 0;
        $sql = "INSERT INTO cart_meja_item (cart_id, produk_id, qty, harga)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE qty = VALUES(qty), harga = IF(VALUES(harga)>0,VALUES(harga),harga), updated_at = CURRENT_TIMESTAMP()";
        return $this->db->query($sql, [$cart_id, $produk_id, $qty, $harga]);
    }

    public function remove_item($cart_id, $produk_id){
        return $this->db->delete('cart_meja_item', ['cart_id'=>(int)$cart_id, 'produk_id'=>(int)$produk_id]);
    }

    public function count_items($cart_id){
        $q = $this->db->select('COALESCE(SUM(qty),0) AS n')->from('cart_meja_item')->where('cart_id',(int)$cart_id)->get()->row();
        return (int)($q->n ?? 0);
    }

    public function sum_total($cart_id){
        $q = $this->db->select('COALESCE(SUM(qty*harga),0) AS t')->from('cart_meja_item')->where('cart_id',(int)$cart_id)->get()->row();
        return (int)($q->t ?? 0);
    }

    public function get_items($cart_id){
        return $this->db->select('i.*, p.nama, p.link_seo AS slug, p.gambar, p.stok')
                        ->from('cart_meja_item i')
                        ->join('produk p', 'p.id = i.produk_id', 'left')
                        ->where('i.cart_id', (int)$cart_id)
                        ->order_by('i.updated_at','DESC')
                        ->get()->result();
    }
}
