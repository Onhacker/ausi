<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_produk extends CI_Model {

    public function __construct(){ parent::__construct(); }

    /** Ambil daftar kategori aktif untuk filter */
    public function get_categories(){
        return $this->db->order_by('nama','ASC')
            ->get_where('kategori_produk', ['is_active'=>1])->result();
    }

    /** Hitung total produk utk pagination */
    public function count_products($filters = []){
        $this->_base_filters($filters);
        return $this->db->count_all_results();
    }

    /** Ambil produk dengan filter + sort + limit */
    public function get_products($filters = [], $limit = 12, $offset = 0, $sort = 'new'){
        $this->_base_select();
        $this->_apply_filters($filters);
        $this->_apply_sort($sort);
        $this->db->limit((int)$limit, (int)$offset);
        return $this->db->get()->result();
    }

    /** Detail by slug */
    public function get_by_slug($slug){
        $this->_base_select();
        $this->db->where('p.link_seo', $slug);
        $this->db->where('p.is_active', 1);
        return $this->db->get()->row();
    }

    // ================== helpers ==================
    private function _base_select(){
        $this->db->from('produk p');
        $this->db->select('p.*, kp.nama as kategori_nama, kp.slug as kategori_slug');
        $this->db->join('kategori_produk kp', 'kp.id = p.kategori_id', 'left');
    }

    private function _base_filters($filters){
        $this->db->from('produk p');
        $this->db->join('kategori_produk kp', 'kp.id = p.kategori_id', 'left');
        $this->db->where('p.is_active', 1);
        $this->db->where('(kp.is_active IS NULL OR kp.is_active = 1)');
        if (!empty($filters['q'])){
            $q = trim($filters['q']);
            $this->db->group_start()
                ->like('p.nama', $q)
                ->or_like('kp.nama', $q)
            ->group_end();
        }
        if (!empty($filters['kategori'])){
            $k = $filters['kategori'];
            if (ctype_digit((string)$k)) $this->db->where('p.kategori_id', (int)$k);
            else $this->db->where('kp.slug', $k);
        }
        if (!empty($filters['sold_out'])){
            $this->db->where('p.stok', 0);
        }
    }

    private function _apply_filters($filters){
        $this->db->where('p.is_active', 1);
        $this->db->where('(kp.is_active IS NULL OR kp.is_active = 1)');
        if (!empty($filters['q'])){
            $q = trim($filters['q']);
            $this->db->group_start()
                ->like('p.nama', $q)
                ->or_like('kp.nama', $q)
            ->group_end();
        }
        if (!empty($filters['kategori'])){
            $k = $filters['kategori'];
            if (ctype_digit((string)$k)) $this->db->where('p.kategori_id', (int)$k);
            else $this->db->where('kp.slug', $k);
        }
        if (!empty($filters['sold_out'])){
            $this->db->where('p.stok', 0);
        }
    }

    private function _apply_sort($sort){
        switch ($sort) {
            case 'price_low':  $this->db->order_by('p.harga','ASC'); break;
            case 'price_high': $this->db->order_by('p.harga','DESC'); break;
            case 'sold_out':   $this->db->order_by('p.nama','ASC'); break; // sudah difilter stok=0
            case 'new':
            default:
                $this->db->order_by('p.created_at','DESC');
                $this->db->order_by('p.id','DESC');
        }
    }
}
